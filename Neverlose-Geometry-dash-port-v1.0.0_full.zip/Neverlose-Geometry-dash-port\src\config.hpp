#pragma once

#include <windows.h>

struct Config {
    bool menuOpen = false;
    bool noclip = false;
    bool godmode = false;
    bool autoJump = false;
    bool freezePlayer = false;
    bool hidePlayer = false;
    bool hideHud = false;
    bool hitboxes = false;
    bool watermark = true;

    bool fly = false;
    float flySpeed = 4.0f;
    bool customTrail = false;
    float trailColor[4] = {0.545f, 0.502f, 0.976f, 1.0f};
    bool showPercentage = false;
    bool showCoords = false;
    bool streamproof = false;
    bool showKeybinds = false;
    static constexpr int KEYBIND_COUNT = 8;
    bool keybindEnabled[KEYBIND_COUNT] = {true, false, false, false, false, false, false, false};
    int keybindKey[KEYBIND_COUNT] = {VK_F1, VK_F2, VK_F3, VK_F4, VK_F5, VK_F6, VK_F7, VK_F8};
    int menuKey = VK_INSERT;

    float speed = 1.0f;
    float accentHue = 0.623f;
    float menuScale = 1.0f;
    float watermarkX = -1.f, watermarkY = -1.f;
    float keybindX = -1.f, keybindY = -1.f;
    int tab = 0;
    int visualSub = 0;

    bool checkpointSet = false;
    bool checkpointDual = false;
    float checkpointX1 = 0.f;
    float checkpointY1 = 0.f;
    float checkpointRot1 = 0.f;
    float checkpointX2 = 0.f;
    float checkpointY2 = 0.f;
    float checkpointRot2 = 0.f;

    bool freezeCaptured = false;
    bool freezeDual = false;
    float freezeX1 = 0.f;
    float freezeY1 = 0.f;
    float freezeRot1 = 0.f;
    float freezeX2 = 0.f;
    float freezeY2 = 0.f;
    float freezeRot2 = 0.f;

    static Config& get();

    void load();
    void save() const;
    bool saveToSlot(int slot) const;
    bool loadFromSlot(int slot);
};

extern HMODULE g_nlDllModule;
