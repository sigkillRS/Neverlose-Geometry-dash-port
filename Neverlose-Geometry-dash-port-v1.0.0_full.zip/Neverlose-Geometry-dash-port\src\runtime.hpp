#pragma once

#include <windows.h>

extern HMODULE g_nlDllModule;

DWORD WINAPI nlStartupThread(LPVOID parameter);
