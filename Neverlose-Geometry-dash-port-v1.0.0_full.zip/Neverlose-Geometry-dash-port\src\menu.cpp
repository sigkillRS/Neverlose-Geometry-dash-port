#include "menu.hpp"
#include "config.hpp"
#include "features.hpp"
#include "resources.hpp"

#include "imgui.h"
#include "imgui_impl_opengl3_loader.h"
#include "menu_core.h"

#include <windows.h>

#include <algorithm>
#include <array>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <memory>
#include <string>
#include <vector>

namespace {

using Color = menu::Color;

menu::Settings g_settings;
menu::State g_state;
std::unique_ptr<menu::Fonts> g_fonts;
bool g_configDirty = false;
bool g_snapAnimations = false;

constexpr std::size_t kAnimCount = 96;
std::array<float, kAnimCount> g_controlHover{};
std::array<float, kAnimCount> g_controlPress{};
std::array<float, kAnimCount> g_controlAnim{};

struct CanvasTexture {
    GLuint id = 0;
    int width = 0, height = 0;

    CanvasTexture() = default;
    CanvasTexture(const CanvasTexture&) = delete;
    CanvasTexture& operator=(const CanvasTexture&) = delete;
    ~CanvasTexture() {
        if (id)
            glDeleteTextures(1, &id);
    }

    void Update(const menu::Canvas& canvas) {
        // A corrupt scale value must never reach glTexImage2D.
        if (canvas.width <= 0 || canvas.height <= 0 || canvas.width > 4096 || canvas.height > 4096)
            return;
        if (canvas.rgba.size() < static_cast<std::size_t>(canvas.width) * canvas.height * 4)
            return;
        if (!id)
            glGenTextures(1, &id);
        width = canvas.width;
        height = canvas.height;

        std::vector<unsigned char> straight(canvas.rgba.size());
        for (std::size_t i = 0; i < canvas.rgba.size(); i += 4) {
            const int a = canvas.rgba[i + 3];
            if (a == 0) {
                straight[i] = straight[i + 1] = straight[i + 2] = 0;
            } else {
                straight[i] = static_cast<unsigned char>(std::min(255, canvas.rgba[i] * 255 / a));
                straight[i + 1] = static_cast<unsigned char>(std::min(255, canvas.rgba[i + 1] * 255 / a));
                straight[i + 2] = static_cast<unsigned char>(std::min(255, canvas.rgba[i + 2] * 255 / a));
            }
            straight[i + 3] = static_cast<unsigned char>(a);
        }

        GLint previous = 0;
        glGetIntegerv(GL_TEXTURE_BINDING_2D, &previous);
        glBindTexture(GL_TEXTURE_2D, id);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                     straight.data());
        glBindTexture(GL_TEXTURE_2D, previous);
    }
};

struct CachedPage {
    CanvasTexture texture;
    std::uint64_t signature = 0;
    bool valid = false;
};

std::array<CachedPage, 6> g_pages;
int g_prevPage = -1;
float g_pageTransition = 1.f;
int g_navAnimId = -1;
float g_navAnim = 1.f;
GLuint g_logoTex = 0;

Color Alpha(Color c, float a) {
    c.a *= a;
    return c;
}

Color Hsv(float h, float s, float v) {
    h = std::fmod(h, 1.f);
    if (h < 0.f)
        h += 1.f;
    const float i = static_cast<float>(std::floor(h * 6.f));
    const float f = h * 6.f - i;
    const float p = v * (1.f - s), q = v * (1.f - f * s), t = v * (1.f - (1.f - f) * s);
    switch (static_cast<int>(i) % 6) {
        case 0: return {v, t, p, 1.f};
        case 1: return {q, v, p, 1.f};
        case 2: return {p, v, t, 1.f};
        case 3: return {p, q, v, 1.f};
        case 4: return {t, p, v, 1.f};
        default: return {v, p, q, 1.f};
    }
}

std::u32string Ascii(const char* text) {
    if (!text)
        return {};
    return menu::ASCII(text);
}

std::u32string Ascii(const std::string& text) {
    return menu::ASCII(text);
}

void ExtractFonts() {
    if (g_fonts)
        return;

    char temp[MAX_PATH] = {0};
    GetTempPathA(MAX_PATH, temp);
    const std::filesystem::path dir = std::filesystem::path(temp) / "nl_overlay_menu_fonts";
    std::error_code ec;
    std::filesystem::create_directories(dir, ec);

    struct FontResource {
        int id;
        const char* name;
    };
    static constexpr FontResource resources[] = {
        {IDR_FONT_NOTO_REGULAR, "NotoSans-Regular.ttf"},
        {IDR_FONT_NOTO_MEDIUM, "NotoSans-Medium.ttf"},
        {IDR_FONT_NOTO_SEMIBOLD, "NotoSans-SemiBold.ttf"},
        {IDR_FONT_MENU_ICONS, "Menu-icons.otf"},
        {IDR_FONT_ESP_ICONS, "ESP-settings-icons.otf"},
        {IDR_FONT_SMALL, "SmallFonts.ttf"},
        {IDR_FONT_STRATUM, "Stratum2Mono-Bold.otf"},
    };

    for (const auto& resource : resources) {
        HRSRC info = FindResourceA(g_nlDllModule, MAKEINTRESOURCEA(resource.id), RT_RCDATA);
        if (!info)
            continue;
        HGLOBAL loaded = LoadResource(g_nlDllModule, info);
        if (!loaded)
            continue;
        const char* bytes = static_cast<const char*>(LockResource(loaded));
        const DWORD size = SizeofResource(g_nlDllModule, info);
        if (!bytes || !size)
            continue;
        std::ofstream out(dir / resource.name, std::ios::binary);
        if (out)
            out.write(bytes, size);
    }

    g_fonts = std::make_unique<menu::Fonts>(dir);
}

void MarkDirty() {
    g_configDirty = true;
}

enum class ControlKind { Info, Toggle, Slider, Button, Combo, Color };

enum class Action {
    None,
    Teleport,
    Checkpoint,
    LoadCheckpoint,
    InstantComplete,
    UnlockIcons,
    UnlockColors,
    UnlockShipsBalls,
    ToggleHitboxes,
    SaveConfig,
    SaveSlot1,
    SaveSlot2,
    SaveSlot3,
    LoadSlot1,
    LoadSlot2,
    LoadSlot3,
    CloseMenu,
};

struct Control {
    ControlKind kind = ControlKind::Info;
    std::u32string label;
    menu::Box box{};
    bool* flag = nullptr;
    float* value = nullptr;
    float min = 0.f, max = 1.f;
    int* integer = nullptr;
    int intMin = 0, intMax = 1;
    Action action = Action::None;
    std::string suffix;
    int animId = 0;
};

struct Card {
    menu::Box box{};
    std::u32string title;
};

struct ContentFrame {
    std::vector<Card> cards;
    std::vector<Control> controls;
};

int g_hoveredControl = -1;
int g_activeSlider = -1;
int g_menuKeyIndex = 0;
float g_scroll = 0.f;
float g_menuPanX = 0.f;
float g_menuPanY = 0.f;
bool g_menuDragging = false;
float g_menuDragX = 0.f;
float g_menuDragY = 0.f;
int g_bindingKeybind = -1;

enum class OverlayDrag { None, Watermark, KeybindList };
OverlayDrag g_overlayDrag = OverlayDrag::None;
float g_overlayDragMouseX = 0.f, g_overlayDragMouseY = 0.f;
float g_overlayDragStartX = 0.f, g_overlayDragStartY = 0.f;
bool g_overlayInputBlocked = false;

bool pointInRect(float x, float y, float rx, float ry, float rw, float rh) {
    return x >= rx && x <= rx + rw && y >= ry && y <= ry + rh;
}

float finiteOr(float value, float fallback) {
    return std::isfinite(value) ? value : fallback;
}

std::uint64_t HashText(std::uint64_t hash, const std::u32string& text) {
    for (char32_t c : text)
        hash = (hash ^ static_cast<std::uint64_t>(c)) * 1099511628211ull;
    return hash;
}

float approach(float current, float target, float dt, float duration) {
    const float step = dt / std::max(0.001f, duration);
    if (current < target)
        return std::min(target, current + step);
    if (current > target)
        return std::max(target, current - step);
    return current;
}

void snapMenuAnimations() {
    for (int i = 0; i < 4; ++i)
        g_state.Tick(1.f);
    g_snapAnimations = true;
    g_hoveredControl = -1;
    g_activeSlider = -1;
    g_controlHover.fill(0.f);
    g_controlPress.fill(0.f);
}

void selectNavigation(int id) {
    Config& cfg = Config::get();
    const int oldPage = std::clamp(cfg.tab == menu::VisualsTab ? 4 + cfg.visualSub : cfg.tab, 0, 5);
    g_state.Select(id);
    if (id == 5 || id == 6) {
        cfg.tab = menu::VisualsTab;
        cfg.visualSub = id - 5;
    } else if (id >= 0 && id < 4) {
        cfg.tab = id;
    }
    const int newPage = std::clamp(cfg.tab == menu::VisualsTab ? 4 + cfg.visualSub : cfg.tab, 0, 5);
    if (newPage != oldPage) {
        g_prevPage = oldPage;
        g_pageTransition = 0.f;
    }
    g_navAnimId = id;
    g_navAnim = 0.f;
    snapMenuAnimations();
    cfg.save();
}

void performAction(Action action) {
    Config& cfg = Config::get();
    switch (action) {
        case Action::Teleport: nl::TeleportToEnd(); break;
        case Action::Checkpoint: nl::SetCheckpoint(); break;
        case Action::LoadCheckpoint: nl::LoadCheckpoint(); break;
        case Action::InstantComplete: nl::InstantComplete(); break;
        case Action::UnlockIcons: nl::UnlockIcons(); break;
        case Action::UnlockColors: nl::UnlockColors(); break;
        case Action::UnlockShipsBalls: nl::UnlockShipsBalls(); break;
        case Action::SaveConfig: cfg.save(); break;
        case Action::SaveSlot1: cfg.saveToSlot(1); break;
        case Action::SaveSlot2: cfg.saveToSlot(2); break;
        case Action::SaveSlot3: cfg.saveToSlot(3); break;
        case Action::LoadSlot1:
            if (cfg.loadFromSlot(1)) {
                cfg.menuOpen = true;
                cfg.save();
            }
            break;
        case Action::LoadSlot2:
            if (cfg.loadFromSlot(2)) {
                cfg.menuOpen = true;
                cfg.save();
            }
            break;
        case Action::LoadSlot3:
            if (cfg.loadFromSlot(3)) {
                cfg.menuOpen = true;
                cfg.save();
            }
            break;
        case Action::CloseMenu: cfg.menuOpen = false; cfg.save(); break;
        default: break;
    }
}

void valueFromMouse(Control& control, float localX, float localY) {
    (void)localY;
    const float t = std::clamp((localX - control.box.x) / std::max(1.f, control.box.w), 0.f, 1.f);
    if (control.value)
        *control.value = control.min + t * (control.max - control.min);
    if (control.integer)
        *control.integer = control.intMin + static_cast<int>(t * (control.intMax - control.intMin) + .5f);
    MarkDirty();
}

std::u32string valueText(const Control& control) {
    if (control.integer) {
        return Ascii(std::to_string(*control.integer).c_str());
    }
    if (control.value) {
        char buffer[32] = {0};
        if (control.suffix == "x")
            std::snprintf(buffer, sizeof(buffer), "%.2fx", *control.value);
        else if (control.suffix == "deg") {
            std::snprintf(buffer, sizeof(buffer), "%.1f", *control.value);
            std::u32string result = Ascii(buffer);
            result += U"\u00b0";
            return result;
        } else
            std::snprintf(buffer, sizeof(buffer), "%.1f", *control.value);
        return Ascii(buffer);
    }
    return {};
}

void addGroup(ContentFrame& frame, const char* title, float x, float& y, float width,
              const std::vector<Control>& controls, float s) {
    const float titleH = 14.f * s;
    const float rowH = 28.f * s;
    const float pitch = 34.f * s;
    frame.cards.push_back({{x, y + 20.f * s, width,
                            controls.size() * pitch + 16.f * s},
                           Ascii(title)});
    y += 20.f * s + titleH + 8.f * s;

    int anim = 0;
    for (Control control : controls) {
        control.box = {x + 14.f * s, y + static_cast<float>(anim) * pitch, width - 28.f * s, rowH};
        control.animId = static_cast<int>(frame.controls.size()) % kAnimCount;
        frame.controls.push_back(control);
        ++anim;
    }
    y = frame.cards.back().box.y + frame.cards.back().box.h + 14.f * s;
}

ContentFrame buildFrame(const menu::Layout& layout, float s) {
    Config& cfg = Config::get();
    ContentFrame frame;
    const float margin = 28.f * s;
    const float gap = 12.f * s;
    const float columnW = std::trunc((layout.content.w - 2.f * margin - gap) * .5f);
    float leftX = layout.content.x + margin;
    float rightX = leftX + columnW + gap;
    float leftY = layout.content.y + 26.f * s;
    float rightY = leftY;

    auto toggle = [&](const char* label, bool* flag, Action action = Action::None) {
        Control c;
        c.kind = ControlKind::Toggle;
        c.label = Ascii(label);
        c.flag = flag;
        c.action = action;
        return c;
    };
    auto slider = [&](const char* label, float* value, float min, float max, const char* suffix) {
        Control c;
        c.kind = ControlKind::Slider;
        c.label = Ascii(label);
        c.value = value;
        c.min = min;
        c.max = max;
        c.suffix = suffix;
        return c;
    };
    auto button = [&](const char* label, Action action) {
        Control c;
        c.kind = ControlKind::Button;
        c.label = Ascii(label);
        c.action = action;
        return c;
    };
    auto info = [&](const char* label) {
        Control c;
        c.kind = ControlKind::Info;
        c.label = Ascii(label);
        return c;
    };
    auto combo = [&](const char* label, int* value, int min, int max) {
        Control c;
        c.kind = ControlKind::Combo;
        c.label = Ascii(label);
        c.integer = value;
        c.intMin = min;
        c.intMax = max;
        return c;
    };

    if (cfg.tab == 0) {
        addGroup(frame, "MAIN", leftX, leftY, columnW,
                 {toggle("Noclip", &cfg.noclip),
                  toggle("Godmode", &cfg.godmode),
                  toggle("Jump Hack", &cfg.autoJump),
                  toggle("Freeze Player", &cfg.freezePlayer)}, s);
        addGroup(frame, "MOVEMENT", rightX, rightY, columnW,
                 {slider("Speedhack", &cfg.speed, 0.10f, 4.f, "x"),
                  toggle("Fly", &cfg.fly),
                  slider("Fly Speed", &cfg.flySpeed, 0.5f, 20.f, "")}, s);
        addGroup(frame, "PRACTICE", rightX, rightY, columnW,
                 {button("Teleport", Action::Teleport),
                  button("Checkpoint", Action::Checkpoint),
                  button("Load CP", Action::LoadCheckpoint),
                  button("Instant Complete", Action::InstantComplete)}, s);
    } else if (cfg.tab == menu::VisualsTab) {
        if (cfg.visualSub == 0) {
            addGroup(frame, "PLAYERS", leftX, leftY, columnW,
                     {toggle("Show Hitboxes", &cfg.hitboxes, Action::ToggleHitboxes),
                      toggle("Hide Player", &cfg.hidePlayer),
                      toggle("Show Percentage", &cfg.showPercentage)}, s);
            addGroup(frame, "TRAIL", rightX, rightY, columnW,
                     {toggle("Custom Trail", &cfg.customTrail)}, s);
        } else {
            addGroup(frame, "INTERFACE", leftX, leftY, columnW,
                     {toggle("Watermark", &cfg.watermark),
                      toggle("Hide HUD", &cfg.hideHud),
                      toggle("Show Coords", &cfg.showCoords),
                      toggle("Keybind List", &cfg.showKeybinds)}, s);
            addGroup(frame, "APPEARANCE", rightX, rightY, columnW,
                     {info("Accent: NL Blue"),
                      slider("Menu Scale", &cfg.menuScale, 0.9f, 1.25f, "")}, s);
        }
    } else if (cfg.tab == 2) {
        addGroup(frame, "UNLOCKS", leftX, leftY, columnW,
                 {button("Unlock All Icons", Action::UnlockIcons),
                  button("Unlock All Colors", Action::UnlockColors),
                  button("Unlock Ships / Balls", Action::UnlockShipsBalls)}, s);
        addGroup(frame, "INFORMATION", rightX, rightY, columnW,
                 {info("Unlocks apply immediately"),
                  info("Icons, colors and game modes"),
                  info("No restart required")}, s);
    } else {
        static const int keyValues[] = {VK_INSERT, VK_F1, VK_F2, VK_F3, VK_HOME, VK_END};
        for (int i = 0; i < 6; ++i)
            if (cfg.menuKey == keyValues[i])
                g_menuKeyIndex = i;
        addGroup(frame, "CONTROLS", leftX, leftY, columnW,
                 {combo("Menu Key", &g_menuKeyIndex, 0, 5),
                  toggle("Streamproof", &cfg.streamproof),
                  toggle("Keybind List", &cfg.showKeybinds),
                  button("Save Config", Action::SaveConfig),
                  button("Close Menu", Action::CloseMenu)}, s);
        addGroup(frame, "CONFIGS", rightX, rightY, columnW,
                 {button("Save Slot 1", Action::SaveSlot1),
                  button("Save Slot 2", Action::SaveSlot2),
                  button("Save Slot 3", Action::SaveSlot3),
                  button("Load Slot 1", Action::LoadSlot1),
                  button("Load Slot 2", Action::LoadSlot2),
                  button("Load Slot 3", Action::LoadSlot3)}, s);
    }
    return frame;
}

std::uint64_t menuSignature(const ContentFrame& frame, const menu::Layout& layout) {
    const Config& cfg = Config::get();
    std::uint64_t hash = 14695981039346656037ull;
    auto mixInt = [&](std::uint64_t value) { hash = (hash ^ value) * 1099511628211ull; };
    auto mixFloat = [&](float value) { mixInt(static_cast<std::uint64_t>(value * 1000.f)); };

    mixInt(cfg.tab);
    mixInt(cfg.visualSub);
    mixInt(static_cast<std::uint64_t>(layout.outer.w));
    mixInt(static_cast<std::uint64_t>(layout.outer.h));
    mixFloat(g_scroll);
    mixInt(g_activeSlider);

    for (std::size_t i = 0; i < frame.controls.size() && i < kAnimCount; ++i) {
        const Control& control = frame.controls[i];
        mixInt(static_cast<std::uint64_t>(control.kind));
        hash = HashText(hash, control.label);
        mixInt(static_cast<std::uint64_t>(g_controlAnim[i] * 15.f));
        if (control.flag)
            mixInt(*control.flag ? 1 : 0);
        if (control.value)
            mixFloat(*control.value);
        if (control.integer)
            mixInt(static_cast<std::uint64_t>(*control.integer));
    }
    return hash;
}

void updateAnimations(const ContentFrame& frame, float dt) {
    for (std::size_t i = 0; i < frame.controls.size() && i < kAnimCount; ++i) {
        const Control& control = frame.controls[i];
        const bool hovered = g_hoveredControl == static_cast<int>(i);
        g_controlHover[i] = approach(g_controlHover[i], hovered ? 1.f : 0.f, dt, .07f);
        g_controlPress[i] =
            approach(g_controlPress[i], hovered && ImGui::IsMouseDown(0) ? 1.f : 0.f, dt, .05f);
        if (control.kind == ControlKind::Toggle && control.flag)
            g_controlAnim[i] = approach(g_controlAnim[i], *control.flag ? 1.f : 0.f, dt, .09f);
    }
}

void processInput(const menu::Layout& layout, ContentFrame& frame, float localX, float localY) {
    Config& cfg = Config::get();
    const bool clicked = ImGui::IsMouseClicked(0);
    const bool down = ImGui::IsMouseDown(0);

    g_state.hover = -1;
    g_state.held = -1;
    for (std::size_t i = 0; i < menu::Tabs.size(); ++i)
        if (layout.rows[i].Contains(localX, localY))
            g_state.hover = static_cast<int>(i);
    if (layout.visualsOpen) {
        if (layout.visualRows[0].Contains(localX, localY))
            g_state.hover = 5;
        if (layout.visualRows[1].Contains(localX, localY))
            g_state.hover = 6;
    }
    if (layout.extensionsRow.Contains(localX, localY))
        g_state.hover = 7;
    if (clicked && g_state.hover >= 0)
        selectNavigation(g_state.hover);

    if (g_activeSlider >= 0 && g_activeSlider < static_cast<int>(frame.controls.size())) {
        if (down) {
            valueFromMouse(frame.controls[g_activeSlider], localX, localY);
        } else {
            g_activeSlider = -1;
        }
        return;
    }

    g_hoveredControl = -1;
    for (std::size_t i = 0; i < frame.controls.size(); ++i) {
        const Control& control = frame.controls[i];
        if (control.kind == ControlKind::Info || !control.box.Contains(localX, localY))
            continue;
        g_hoveredControl = static_cast<int>(i);
        if (!clicked)
            continue;

        if (control.kind == ControlKind::Toggle && control.flag) {
            *control.flag = !*control.flag;
            MarkDirty();
            if (control.action == Action::ToggleHitboxes)
                nl::ToggleHitboxes();
        } else if (control.kind == ControlKind::Slider) {
            g_activeSlider = static_cast<int>(i);
            valueFromMouse(frame.controls[i], localX, localY);
        } else if (control.kind == ControlKind::Button) {
            performAction(control.action);
        } else if (control.kind == ControlKind::Combo && control.integer) {
            *control.integer = control.intMin +
                               (*control.integer - control.intMin + 1) % (control.intMax - control.intMin + 1);
            if (control.label == Ascii("Menu Key")) {
                static const int keyValues[] = {VK_INSERT, VK_F1, VK_F2, VK_F3, VK_HOME, VK_END};
                cfg.menuKey = keyValues[std::clamp(*control.integer, 0, 5)];
            }
            MarkDirty();
        }
        break;
    }
}

void drawContent(menu::Canvas& canvas, menu::Fonts& fonts, const ContentFrame& frame,
                 const std::array<Color, 46>& palette, float s, const menu::Box& clip) {
    const float px = 13.f * s;
    auto enabledAlpha = [&](const Control& control) { return control.flag && !*control.flag ? .55f : 1.f; };

    fonts.Text(canvas, 0, 22.f * s, U"GEOMETRY DASH",
               {clip.x, clip.y - 18.f * s, clip.w, 16.f * s}, palette[3]);

    for (const Card& card : frame.cards)
        canvas.RoundRect(card.box, 15.f * s, palette[40], palette[11], 1.f * s, 1.f, 15, &clip);

    const menu::Box cardClip = clip;
    for (const Card& card : frame.cards) {
        fonts.Text(canvas, 0, 13.f * s, card.title,
                   {card.box.x, card.box.y - 18.f * s, card.box.w, 13.f * s}, palette[3], false,
                   &cardClip);
    }

    for (std::size_t i = 0; i < frame.controls.size() && i < kAnimCount; ++i) {
        const Control& control = frame.controls[i];
        const float hover = g_controlHover[i];
        const float press = g_controlPress[i];
        const float a = enabledAlpha(control);
        const float t = std::clamp(g_controlAnim[i], 0.f, 1.f);
        const menu::Box& row = control.box;
        const float textPx = 15.f * s;
        const float ty = row.y + (row.h - textPx) * .5f;

        if (i > 0 && frame.controls[i - 1].box.y < row.y &&
            std::fabs(frame.controls[i - 1].box.x - row.x) < 1.f)
            canvas.RoundRect({row.x, row.y - 1.f, row.w, 1.f}, 0.f, palette[34], {0, 0, 0, 0}, 0.f,
                             0.f, 15, &clip);

        canvas.RoundRect(row, 15.f * s / 1.6f, Alpha(palette[33], .4f * hover * a), {0, 0, 0, 0},
                         0.f, 1.f, 15, &clip);

        const Color ink = Alpha(menu::Mix(palette[0], palette[2], std::max(hover, press)), a);
        float labelRight = row.x + row.w;

        if (control.kind == ControlKind::Toggle) {
            const float nominal = 20.f * s;
            const float center = row.y + row.h * .5f;
            const float frac = center - std::trunc(center);
            const menu::Box track{row.x + row.w - 48.f * s, center - nominal * .5f + frac,
                                  48.f * s, nominal - 2.f * frac};
            canvas.RoundRect(track, nominal * .5f, Alpha(palette[22], a), {0, 0, 0, 0}, 0.f, 1.f,
                             15, &clip);
            canvas.RoundRect(track, nominal * .5f, Alpha(palette[23], a * t), {0, 0, 0, 0}, 0.f,
                             1.f, 15, &clip);
            const float r = nominal * .5f - 3.f * s;
            const float cx = track.x + nominal * .5f + (track.w - nominal) * t;
            canvas.RoundRect({cx - r, center - r, 2.f * r, 2.f * r}, r,
                             Alpha(menu::Mix(palette[20], palette[21], t), a), {0, 0, 0, 0}, 0.f,
                             1.f, 15, &clip);
            labelRight = track.x - 10.f * s;
        } else if (control.kind == ControlKind::Slider) {
            const std::u32string value = valueText(control);
            const float tw = fonts.Width(0, textPx, value);
            const float nw = std::min(std::max(36.f * s, tw + 16.f * s), row.w * .42f);
            const float nh = 22.f * s;
            const menu::Box number{row.x + row.w - nw, row.y + (row.h - nh) * .5f, nw, nh};
            const float total = std::min((row.w) * .70f, std::trunc(row.w / 2.0f) + 20.f * s);
            const menu::Box track{row.x + row.w - total, row.y + (row.h - 6.f * s) * .5f,
                                  std::max(1.f, total - nw - 14.f * s), 6.f * s};
            const float v = control.value
                                ? std::clamp((*control.value - control.min) /
                                                 std::max(.0001f, control.max - control.min),
                                             0.f, 1.f)
                                : std::clamp(static_cast<float>(*control.integer - control.intMin) /
                                                 std::max(1, control.intMax - control.intMin),
                                             0.f, 1.f);
            const float base = 4.f * s;
            const float inset = std::min(base, std::max(0.f, (track.w - 6.f) * .5f));
            const float cx = track.x + inset + (track.w - 2.f * inset) * v;
            const float r = base + hover * s;
            canvas.RoundRect(track, 3.f * s, Alpha(palette[24], a), {0, 0, 0, 0}, 0.f, 1.f, 15, &clip);
            canvas.RoundRect({track.x, track.y, std::max(0.f, cx - r - track.x), track.h}, 3.f * s,
                             Alpha(palette[25], a), {0, 0, 0, 0}, 0.f, 1.f, 15, &clip);
            if (r > 0.f)
                canvas.RoundRect({cx - r, row.y + row.h * .5f - r, 2.f * r, 2.f * r}, r,
                                 Alpha(menu::Mix(palette[26], palette[27], hover), a),
                                 {0, 0, 0, 0}, 0.f, 1.f, 15, &clip);
            canvas.RoundRect(number, 8.f * s,
                             Alpha(menu::Mix(palette[12], palette[13], hover), a), {0, 0, 0, 0},
                             0.f, 1.f, 15, &clip);
            canvas.RoundRect(number, 8.f * s, {0, 0, 0, 0}, Alpha(palette[11], a), 1.f * s, 1.f, 15,
                             &clip);
            fonts.Text(canvas, 0, textPx, value,
                       {number.x + 8.f * s, ty, std::max(0.f, number.w - 16.f * s), textPx},
                       Alpha(palette[14], a), false, &clip);
            labelRight = track.x - 10.f * s;
        } else if (control.kind == ControlKind::Button || control.kind == ControlKind::Combo) {
            const menu::Box box{row.x + row.w - std::min(row.w * .55f, 160.f * s), row.y + 2.f * s,
                                std::min(row.w * .55f, 160.f * s), row.h - 4.f * s};
            canvas.RoundRect(box, 8.f * s, Alpha(menu::Mix(palette[12], palette[13], hover), a),
                             {0, 0, 0, 0}, 0.f, 1.f, 15, &clip);
            canvas.RoundRect(box, 8.f * s, {0, 0, 0, 0}, Alpha(palette[11], a), 1.f * s, 1.f, 15,
                             &clip);
            fonts.Text(canvas, 0, textPx, control.label, box, ink, false, &clip);
            if (control.kind == ControlKind::Combo)
                fonts.Text(canvas, 3, textPx, U"\uf107",
                           {box.x + box.w - 22.f * s, box.y, 14.f * s, box.h}, ink, true, &clip);
            labelRight = box.x - 10.f * s;
        } else if (control.kind == ControlKind::Color) {
            const menu::Box swatch{row.x + row.w - 20.f * s, row.y + (row.h - 16.f * s) * .5f,
                                   16.f * s, 16.f * s};
            canvas.RoundRect(swatch, 4.f * s, palette[23], palette[11], 1.f * s, 1.f, 15, &clip);
            labelRight = swatch.x - 6.f * s;
        }

        fonts.Text(canvas, 0, textPx, control.label,
                   {row.x, ty, std::max(0.f, labelRight - row.x), textPx}, ink, false, &clip);
    }
}

void blit(CanvasTexture& texture, float x, float y, float alpha = 1.f) {
    if (!texture.id || texture.width <= 0 || texture.height <= 0)
        return;
    ImU32 tint = IM_COL32(255, 255, 255, static_cast<int>(std::clamp(alpha, 0.f, 1.f) * 255.f));
    ImGui::GetForegroundDrawList()->AddImage(static_cast<ImTextureID>(texture.id), ImVec2(x, y),
                                             ImVec2(x + texture.width, y + texture.height),
                                             ImVec2(0, 0), ImVec2(1, 1), tint);
}

ImU32 imguiColor(Color c) {
    return IM_COL32(static_cast<int>(c.r * 255.f), static_cast<int>(c.g * 255.f),
                    static_cast<int>(c.b * 255.f), static_cast<int>(c.a * 255.f));
}

void drawHud() {
    Config& cfg = Config::get();
    if (!cfg.showPercentage && !cfg.showCoords)
        return;

    float x = 0.f, y = 0.f, progress = 0.f;
    if (!nl::GetPlayerState(x, y, progress))
        return;

    char buffer[96] = {0};
    if (cfg.showPercentage && cfg.showCoords)
        std::snprintf(buffer, sizeof(buffer), "%5.1f%%   X %6.1f  Y %6.1f", progress, x, y);
    else if (cfg.showPercentage)
        std::snprintf(buffer, sizeof(buffer), "%5.1f%%", progress);
    else
        std::snprintf(buffer, sizeof(buffer), "X %6.1f  Y %6.1f", x, y);

    const auto palette = menu::CurrentPalette(g_settings);
    const ImVec2 pad{9.f, 6.f};
    const ImVec2 size{ImGui::CalcTextSize(buffer).x + pad.x * 2.f,
                      ImGui::CalcTextSize(buffer).y + pad.y * 2.f};
    const ImVec2 pos{16.f, 16.f};
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    dl->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), imguiColor(Alpha(palette[9], .92f)),
                      6.f);
    dl->AddRect(pos, ImVec2(pos.x + size.x, pos.y + size.y), imguiColor(palette[11]), 6.f, 0, 1.f);
    dl->AddRectFilled({pos.x, pos.y + 4.f}, {pos.x + 2.f, pos.y + size.y - 4.f}, imguiColor(palette[23]),
                      1.f);
    dl->AddText(ImVec2(pos.x + pad.x, pos.y + pad.y - 1.f), imguiColor(palette[2]), buffer);
}

const char* keybindActionName(int i) {
    static const char* names[] = {"Noclip", "Godmode", "Jump Hack", "Speedhack",
                                  "Fly", "Hide Player", "Hitboxes", "Watermark"};
    return (i >= 0 && i < 8) ? names[i] : "";
}

bool* keybindActionFlag(int i) {
    Config& cfg = Config::get();
    bool* flags[] = {&cfg.noclip, &cfg.godmode, &cfg.autoJump, nullptr,
                     &cfg.fly, &cfg.hidePlayer, &cfg.hitboxes, &cfg.watermark};
    return (i >= 0 && i < 8) ? flags[i] : nullptr;
}

std::string keyName(int vk) {
    if (vk >= 'A' && vk <= 'Z') return std::string(1, char(vk));
    if (vk >= '0' && vk <= '9') return std::string(1, char(vk));
    if (vk >= VK_F1 && vk <= VK_F24) return "F" + std::to_string(vk - VK_F1 + 1);
    switch (vk) {
        case VK_INSERT: return "INS"; case VK_DELETE: return "DEL"; case VK_HOME: return "HOME";
        case VK_END: return "END"; case VK_TAB: return "TAB"; case VK_SPACE: return "SPACE";
        case VK_LSHIFT: case VK_RSHIFT: case VK_SHIFT: return "SHIFT";
        case VK_LCONTROL: case VK_RCONTROL: case VK_CONTROL: return "CTRL";
        case VK_MENU: return "ALT"; case VK_MBUTTON: return "M3";
        case VK_XBUTTON1: return "M4"; case VK_XBUTTON2: return "M5";
        default: return "K" + std::to_string(vk);
    }
}

ImFont* g_uiFont = nullptr;

void drawKeybindList() {
    Config& cfg = Config::get();
    if (cfg.streamproof || !cfg.showKeybinds)
        return;
    const auto palette = menu::CurrentPalette(g_settings);
    const float s = g_settings.scale;
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    const ImVec2 screen = ImGui::GetIO().DisplaySize;
    ImFont* font = g_uiFont ? g_uiFont : ImGui::GetFont();
    const float fontSize = 14.f * s;
    const float rowH = 25.f * s;
    const float pad = 14.f * s;
    const float w = 255.f * s;
    const float titleH = 34.f * s;
    const float badgeW = 46.f * s;

    int visible = 0;
    for (int i = 0; i < Config::KEYBIND_COUNT; ++i)
        if (cfg.keybindEnabled[i]) ++visible;
    if (visible == 0) visible = 1;
    const float h = titleH + visible * rowH + pad;

    ImVec2 pos{finiteOr(cfg.keybindX, -1.f), finiteOr(cfg.keybindY, -1.f)};
    bool moved = false;
    if (pos.x < 0.f || pos.y < 0.f) {
        pos = {screen.x - w - 8.f * s, 62.f * s};
        moved = true;
    }
    const ImVec2 clamped{std::clamp(pos.x, 0.f, std::max(0.f, screen.x - w)),
                         std::clamp(pos.y, 0.f, std::max(0.f, screen.y - h))};
    if (std::fabs(clamped.x - pos.x) > .5f || std::fabs(clamped.y - pos.y) > .5f) {
        pos = clamped;
        moved = true;
    }
    if (moved) {
        cfg.keybindX = pos.x;
        cfg.keybindY = pos.y;
        cfg.save();
    }

    const ImVec2 mouse = ImGui::GetMousePos();
    const bool mouseValid = ImGui::IsMousePosValid();
    if (mouseValid && pointInRect(mouse.x, mouse.y, pos.x, pos.y, w, h))
        g_overlayInputBlocked = true;

    // Header is the drag handle so row badges keep their own click behaviour.
    if (mouseValid && g_overlayDrag == OverlayDrag::None && ImGui::IsMouseClicked(0) &&
        pointInRect(mouse.x, mouse.y, pos.x, pos.y, w, titleH)) {
        g_overlayDrag = OverlayDrag::KeybindList;
        g_overlayDragMouseX = mouse.x;
        g_overlayDragMouseY = mouse.y;
        g_overlayDragStartX = pos.x;
        g_overlayDragStartY = pos.y;
    }
    if (g_overlayDrag == OverlayDrag::KeybindList) {
        if (ImGui::IsMouseDown(0) && mouseValid) {
            cfg.keybindX = std::clamp(g_overlayDragStartX + mouse.x - g_overlayDragMouseX, 0.f,
                                      std::max(0.f, screen.x - w));
            cfg.keybindY = std::clamp(g_overlayDragStartY + mouse.y - g_overlayDragMouseY, 0.f,
                                      std::max(0.f, screen.y - h));
            pos = {cfg.keybindX, cfg.keybindY};
        } else {
            g_overlayDrag = OverlayDrag::None;
            cfg.save();
        }
    }

    const float radius = 14.f * s;
    for (int i = 3; i >= 1; --i) {
        float e = i * 6.f * s;
        dl->AddRectFilled({pos.x - e * .2f, pos.y + e * .4f},
                          {pos.x + w + e * .2f, pos.y + h + e * .4f}, IM_COL32(0, 0, 0, 18 * i),
                          radius + e * .3f);
    }
    dl->AddRectFilled({pos.x - 1.f, pos.y - 1.f}, {pos.x + w + 1.f, pos.y + h + 1.f},
                      imguiColor(Alpha(palette[23], .12f)), radius + 2.f);
    dl->AddRectFilled(pos, {pos.x + w, pos.y + h}, imguiColor(Alpha(Color{.07f, .07f, .09f, 1.f}, .96f)),
                      radius);
    dl->AddRect(pos, {pos.x + w, pos.y + h}, imguiColor(Alpha(palette[23], .35f)), radius, 0, 1.2f);
    dl->AddText(font, fontSize + 1.f * s, {pos.x + pad, pos.y + 9.f * s},
                imguiColor(palette[0]), "KEYBINDS");
    dl->AddRectFilled({pos.x + pad, pos.y + titleH - 6.f * s},
                      {pos.x + w - pad, pos.y + titleH - 5.f * s},
                      imguiColor(Alpha(palette[34], .7f)));

    float y = pos.y + titleH;
    bool any = false;
    for (int i = 0; i < Config::KEYBIND_COUNT; ++i) {
        if (!cfg.keybindEnabled[i]) continue;
        any = true;
        bool* flag = keybindActionFlag(i);
        bool on = flag ? *flag : false;
        const float cb = 15.f * s;
        const ImVec2 cbPos{pos.x + pad, y + (rowH - cb) * .5f};
        dl->AddRectFilled(cbPos, {cbPos.x + cb, cbPos.y + cb},
                          imguiColor(on ? palette[23] : palette[22]), 4.f * s);
        dl->AddRect(cbPos, {cbPos.x + cb, cbPos.y + cb}, imguiColor(Alpha(palette[11], .85f)), 4.f * s,
                    0, 1.f);
        if (on) {
            dl->AddLine({cbPos.x + 3.f * s, cbPos.y + cb * .55f},
                        {cbPos.x + cb * .44f, cbPos.y + cb - 3.f * s}, imguiColor(palette[0]),
                        1.8f * s);
            dl->AddLine({cbPos.x + cb * .44f, cbPos.y + cb - 3.f * s},
                        {cbPos.x + cb - 3.f * s, cbPos.y + 3.f * s}, imguiColor(palette[0]),
                        1.8f * s);
        }
        const float textY = y + (rowH - fontSize) * .5f;
        dl->AddText(font, fontSize, {cbPos.x + cb + 10.f * s, textY},
                    imguiColor(on ? palette[0] : Alpha(palette[0], .7f)), keybindActionName(i));

        const ImVec2 badge{pos.x + w - pad - badgeW, y + 3.f * s};
        const ImVec2 badgeEnd{badge.x + badgeW, badge.y + rowH - 6.f * s};
        const bool binding = g_bindingKeybind == i;
        dl->AddRectFilled(badge, badgeEnd,
                          imguiColor(Alpha(binding ? palette[23] : palette[33], binding ? .65f : .25f)),
                          7.f * s);
        dl->AddRect(badge, badgeEnd, imguiColor(Alpha(palette[23], binding ? 1.f : .4f)), 7.f * s,
                    0, 1.f);
        std::string kn = binding ? "..." : keyName(cfg.keybindKey[i]);
        const float kw = font->CalcTextSizeA(fontSize, FLT_MAX, 0.f, kn.c_str()).x;
        dl->AddText(font, fontSize, {badge.x + (badgeW - kw) * .5f, textY},
                    imguiColor(binding ? palette[0] : palette[2]), kn.c_str());
        if (mouseValid && g_bindingKeybind < 0 &&
            ((ImGui::IsMouseClicked(0) && pointInRect(mouse.x, mouse.y, badge.x, badge.y,
                                                      badgeEnd.x - badge.x, badgeEnd.y - badge.y)) ||
             (ImGui::IsMouseClicked(1) && pointInRect(mouse.x, mouse.y, pos.x, y, w, rowH)))) {
            g_bindingKeybind = i;
        }
        y += rowH;
    }
    if (!any)
        dl->AddText(font, fontSize, {pos.x + pad, y + 3.f * s}, imguiColor(palette[3]),
                    "No active binds");

    if (g_bindingKeybind >= 0 && g_bindingKeybind < Config::KEYBIND_COUNT) {
        const float bw = 210.f * s, bh = 42.f * s;
        const ImVec2 bp{screen.x * .5f - bw * .5f, screen.y * .5f - bh * .5f};
        for (int i = 3; i >= 1; --i) {
            float e = i * 7.f * s;
            dl->AddRectFilled({bp.x - e * .2f, bp.y + e * .4f},
                              {bp.x + bw + e * .2f, bp.y + bh + e * .4f},
                              IM_COL32(0, 0, 0, 20 * i), 14.f * s + e * .3f);
        }
        dl->AddRectFilled(bp, {bp.x + bw, bp.y + bh},
                          imguiColor(Alpha(Color{.07f, .07f, .09f, 1.f}, .97f)), 14.f * s);
        dl->AddRect(bp, {bp.x + bw, bp.y + bh}, imguiColor(Alpha(palette[23], .8f)), 14.f * s, 0,
                    1.5f);
        const char* label = "PRESS A KEY / MOUSE BUTTON";
        const float tw = font->CalcTextSizeA(fontSize + 1.f * s, FLT_MAX, 0.f, label).x;
        dl->AddText(font, fontSize + 1.f * s, {bp.x + (bw - tw) * .5f, bp.y + 13.f * s},
                    imguiColor(palette[0]), label);
    }
}

void drawWatermark() {
    Config& cfg = Config::get();
    if (cfg.streamproof || !cfg.watermark)
        return;

    const auto palette = menu::CurrentPalette(g_settings);
    const float s = g_settings.scale;
    const float H = 42.f * s;
    const float pad = 14.f * s;
    const ImVec2 screen = ImGui::GetIO().DisplaySize;
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    ImFont* font = g_uiFont ? g_uiFont : ImGui::GetFont();
    const float fontSize = 15.f * s;

    char fpsBuf[32] = {0};
    std::snprintf(fpsBuf, sizeof(fpsBuf), "%d FPS", static_cast<int>(ImGui::GetIO().Framerate + 0.5f));
    SYSTEMTIME st{};
    GetLocalTime(&st);
    char timeBuf[16] = {0};
    std::snprintf(timeBuf, sizeof(timeBuf), "%02u:%02u", st.wHour, st.wMinute);

    const float iconW = H * .36f * 79.3f / 46.7f;
    const float fpsW = font->CalcTextSizeA(fontSize, FLT_MAX, 0.f, fpsBuf).x;
    const float timeW = font->CalcTextSizeA(fontSize, FLT_MAX, 0.f, timeBuf).x;
    const float sep = 12.f * s;
    const float W = pad + iconW + sep + fpsW + sep + timeW + pad;

    ImVec2 pos{finiteOr(cfg.watermarkX, -1.f), finiteOr(cfg.watermarkY, -1.f)};
    bool moved = false;
    if (pos.x < 0.f || pos.y < 0.f) {
        pos = {screen.x - W - 8.f * s, 8.f * s};
        moved = true;
    }
    const ImVec2 clamped{std::clamp(pos.x, 0.f, std::max(0.f, screen.x - W)),
                         std::clamp(pos.y, 0.f, std::max(0.f, screen.y - H))};
    if (std::fabs(clamped.x - pos.x) > .5f || std::fabs(clamped.y - pos.y) > .5f) {
        pos = clamped;
        moved = true;
    }
    if (moved) {
        cfg.watermarkX = pos.x;
        cfg.watermarkY = pos.y;
        cfg.save();
    }

    const ImVec2 mouse = ImGui::GetMousePos();
    const bool mouseValid = ImGui::IsMousePosValid();
    if (mouseValid && pointInRect(mouse.x, mouse.y, pos.x, pos.y, W, H))
        g_overlayInputBlocked = true;

    if (mouseValid && g_overlayDrag == OverlayDrag::None && ImGui::IsMouseClicked(0) &&
        pointInRect(mouse.x, mouse.y, pos.x, pos.y, W, H)) {
        g_overlayDrag = OverlayDrag::Watermark;
        g_overlayDragMouseX = mouse.x;
        g_overlayDragMouseY = mouse.y;
        g_overlayDragStartX = pos.x;
        g_overlayDragStartY = pos.y;
    }
    if (g_overlayDrag == OverlayDrag::Watermark) {
        if (ImGui::IsMouseDown(0) && mouseValid) {
            cfg.watermarkX = std::clamp(g_overlayDragStartX + mouse.x - g_overlayDragMouseX, 0.f,
                                        std::max(0.f, screen.x - W));
            cfg.watermarkY = std::clamp(g_overlayDragStartY + mouse.y - g_overlayDragMouseY, 0.f,
                                        std::max(0.f, screen.y - H));
            pos = {cfg.watermarkX, cfg.watermarkY};
        } else {
            g_overlayDrag = OverlayDrag::None;
            cfg.save();
        }
    }

    const float radius = 14.f * s;
    // Glow / shadow
    for (int i = 3; i >= 1; --i) {
        float e = i * 6.f * s;
        dl->AddRectFilled({pos.x - e*0.2f, pos.y + e*0.4f}, {pos.x + W + e*0.2f, pos.y + H + e*0.4f},
                          IM_COL32(0, 0, 0, 18 * i), radius + e*0.3f);
    }
    dl->AddRectFilled({pos.x - 1.f, pos.y - 1.f}, {pos.x + W + 1.f, pos.y + H + 1.f},
                      imguiColor(Alpha(palette[23], .12f)), radius + 2.f);
    dl->AddRectFilled(pos, {pos.x + W, pos.y + H}, imguiColor(Alpha(Color{.07f,.07f,.09f,1.f}, .96f)), radius);
    dl->AddRect(pos, {pos.x + W, pos.y + H}, imguiColor(Alpha(palette[23], .35f)), radius, 0, 1.2f);

    float x = pos.x + pad;
    const float logoH = H * .36f, logoW = logoH * 51.f / 30.f;
    const float logoY = pos.y + (H - logoH) * .5f;
    if (g_logoTex)
        dl->AddImage(static_cast<ImTextureID>(g_logoTex), ImVec2(x, logoY),
                     ImVec2(x + logoW, logoY + logoH), ImVec2(0, 0), ImVec2(1, 1));
    x += iconW + sep;

    const float ty = pos.y + (H - fontSize) * .5f - 1.f * s;
    auto sepLine = [&](float sx) {
        dl->AddRectFilled({sx - sep * .5f, pos.y + 11.f * s}, {sx - sep * .5f + 1.f, pos.y + H - 11.f * s},
                          imguiColor(Alpha(palette[34], .7f)));
    };
    sepLine(x);
    dl->AddText(font, fontSize, {x, ty}, imguiColor(palette[0]), fpsBuf);
    x += fpsW + sep;
    sepLine(x);
    dl->AddText(font, fontSize, {x, ty}, imguiColor(Alpha(palette[0], .85f)), timeBuf);
}

} // namespace

void ensureLogoTexture() {
    if (g_logoTex)
        return;
    glGenTextures(1, &g_logoTex);
    GLint previous = 0;
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &previous);
    glBindTexture(GL_TEXTURE_2D, g_logoTex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    // Keep fully transparent pixels white so linear filtering cannot bleed
    // black fringes into the anti-aliased logo edges.
    std::array<unsigned char, 51 * 30 * 4> logo{};
    std::memcpy(logo.data(), wm::LogoRGBA, logo.size());
    for (std::size_t i = 0; i < logo.size(); i += 4)
        if (logo[i + 3] == 0)
            logo[i] = logo[i + 1] = logo[i + 2] = 255;
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 51, 30, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                 logo.data());
    glBindTexture(GL_TEXTURE_2D, previous);
}

void nlSetupMenu() {
    ExtractFonts();
    try {
        char temp[MAX_PATH] = {0};
        GetTempPathA(MAX_PATH, temp);
        const std::filesystem::path dir = std::filesystem::path(temp) / "nl_overlay_menu_fonts";
        ImGuiIO& io = ImGui::GetIO();
        std::string p = (dir / "NotoSans-SemiBold.ttf").string();
        if (std::filesystem::exists(p))
            g_uiFont = io.Fonts->AddFontFromFileTTF(p.c_str(), 18.0f);
        if (!g_uiFont)
            g_uiFont = io.Fonts->AddFontDefault();
    } catch (...) {}
}

void nlHandleKeybind(int vk) {
    Config& cfg = Config::get();
    for (int i = 0; i < Config::KEYBIND_COUNT; ++i) {
        if (!cfg.keybindEnabled[i] || cfg.keybindKey[i] != vk)
            continue;
        bool* flag = keybindActionFlag(i);
        if (flag) {
            *flag = !*flag;
            if (flag == &cfg.hitboxes)
                nl::ToggleHitboxes();
            cfg.save();
        }
    }
}

bool nlConsumeBindInput(int vk) {
    if (g_bindingKeybind < 0)
        return false;
    const int index = g_bindingKeybind;
    g_bindingKeybind = -1;
    if (vk == VK_ESCAPE)
        return true;
    Config& cfg = Config::get();
    cfg.keybindKey[index] = std::clamp(vk, 1, 254);
    cfg.keybindEnabled[index] = true;
    cfg.save();
    return true;
}

bool nlIsInputBlocked() {
    return Config::get().menuOpen || g_overlayDrag != OverlayDrag::None ||
           g_overlayInputBlocked || g_bindingKeybind >= 0;
}

void nlDrawMenu() {
    if (!g_fonts)
        return;
    ensureLogoTexture();

    Config& cfg = Config::get();
    g_overlayInputBlocked = false;
    g_settings.scale = std::clamp(finiteOr(cfg.menuScale, 1.f), .9f, 1.25f);
    // Use the stock OverlayMenu palette: its accent is RGB(0.31, 0.49, 1.0),
    // the same NL blue as the logo. Custom HSV values used to drift purple.
    g_settings.customAccent = false;
    g_settings.demoBackground = false;
    g_settings.shadow = false;
    // CPU blur in menu::Render is re-executed on every cache invalidation and
    // was the main cause of multi-second stalls when switching tabs.
    g_settings.blur = false;

    drawHud();
    drawWatermark();
    drawKeybindList();

    if (g_configDirty) {
        cfg.save();
        g_configDirty = false;
    }

    const bool blockInput = nlIsInputBlocked();
    ImGui::GetIO().WantCaptureMouse = blockInput;
    ImGui::GetIO().WantCaptureKeyboard = blockInput || g_bindingKeybind >= 0;
    if (!cfg.menuOpen)
        return;

    const ImVec2 screen = ImGui::GetIO().DisplaySize;
    const float dt = std::min(ImGui::GetIO().DeltaTime, .1f);
    g_state.Tick(g_snapAnimations ? 1.f : dt);
    g_snapAnimations = false;
    if (g_pageTransition < 1.f)
        g_pageTransition = std::min(1.f, g_pageTransition + dt / .18f);

    menu::Layout layout = menu::AnimatedLayout(static_cast<int>(screen.x),
                                               static_cast<int>(screen.y), g_settings, g_state,
                                               g_menuPanX, g_menuPanY);
    const ImVec2 mouse = ImGui::GetIO().MousePos;
    const bool mouseDown = ImGui::IsMouseDown(0);
    const bool mouseClicked = ImGui::IsMouseClicked(0);
    menu::Layout local = menu::TranslateLayout(layout, -layout.outer.x, -layout.outer.y);
    ContentFrame frame = buildFrame(local, g_settings.scale);

    if (mouseClicked) {
        const bool overNav = menu::Hit(layout, mouse.x, mouse.y) >= 0;
        const menu::Box profile{layout.sidebar.x, layout.outer.y + layout.outer.h - layout.footerHeight,
                                layout.sidebar.w, layout.footerHeight};
        bool overControl = false;
        const float lx = mouse.x - layout.outer.x, ly = mouse.y - layout.outer.y;
        for (const Control& c : frame.controls)
            if (c.kind != ControlKind::Info && c.box.Contains(lx, ly)) { overControl = true; break; }
        if (layout.outer.Contains(mouse.x, mouse.y) && !overNav && !profile.Contains(mouse.x, mouse.y) && !overControl) {
            g_menuDragging = true;
            g_menuDragX = mouse.x;
            g_menuDragY = mouse.y;
        }
    }
    if (g_menuDragging) {
        if (mouseDown) {
            g_menuPanX -= (mouse.x - g_menuDragX);
            g_menuPanY -= (mouse.y - g_menuDragY);
            g_menuDragX = mouse.x;
            g_menuDragY = mouse.y;
            layout = menu::AnimatedLayout(static_cast<int>(screen.x), static_cast<int>(screen.y),
                                          g_settings, g_state, g_menuPanX, g_menuPanY);
            float nx = std::clamp(layout.outer.x, std::min(0.f, screen.x - layout.outer.w),
                                  std::max(0.f, screen.x - layout.outer.w));
            float ny = std::clamp(layout.outer.y, 0.f,
                                  std::max(0.f, screen.y - layout.headerHeight));
            g_menuPanX += layout.outer.x - nx;
            g_menuPanY += layout.outer.y - ny;
            layout = menu::AnimatedLayout(static_cast<int>(screen.x), static_cast<int>(screen.y),
                                          g_settings, g_state, g_menuPanX, g_menuPanY);
            local = menu::TranslateLayout(layout, -layout.outer.x, -layout.outer.y);
            frame = buildFrame(local, g_settings.scale);
        } else {
            g_menuDragging = false;
        }
    }

    const float localX = mouse.x - layout.outer.x;
    const float localY = mouse.y - layout.outer.y;
    if (!g_menuDragging)
        processInput(local, frame, localX, localY);
    updateAnimations(frame, dt);

    const int page = cfg.tab == menu::VisualsTab ? 4 + cfg.visualSub : cfg.tab;
    CachedPage& cached = g_pages[std::clamp(page, 0, static_cast<int>(g_pages.size()) - 1)];
    const int textureW = std::clamp(static_cast<int>(std::ceil(layout.outer.w)), 1, 4096);
    const int textureH = std::clamp(static_cast<int>(std::ceil(layout.outer.h)), 1, 4096);
    const std::uint64_t signature = menuSignature(frame, local);
    const bool resized = cached.texture.width != textureW || cached.texture.height != textureH;
    if (!cached.valid || resized || signature != cached.signature) {
        menu::Canvas canvas(textureW, textureH);
        menu::Render(canvas, *g_fonts, g_settings, g_state, local, false);
        drawContent(canvas, *g_fonts, frame, menu::CurrentPalette(g_settings), g_settings.scale,
                    local.content);
        cached.texture.Update(canvas);
        cached.signature = signature;
        cached.valid = true;
    }

    ImDrawList* dl = ImGui::GetForegroundDrawList();
    dl->AddRectFilled({0.f, 0.f}, screen, IM_COL32(0, 0, 0, 70));

    const bool transitioning = g_prevPage >= 0 && g_pageTransition < 1.f &&
                               g_pages[g_prevPage].valid;
    if (!transitioning) {
        blit(cached.texture, layout.outer.x, layout.outer.y);
    } else {
        const float raw = std::clamp(g_pageTransition, 0.f, 1.f);
        const float t = raw * raw * (3.f - 2.f * raw);
        const float slide = 22.f * g_settings.scale;
        CachedPage& prev = g_pages[g_prevPage];
        blit(prev.texture, layout.outer.x - t * slide, layout.outer.y, 1.f - t);
        blit(cached.texture, layout.outer.x + (1.f - t) * slide, layout.outer.y, t);
        if (raw >= 1.f)
            g_prevPage = -1;
    }

    // Nav switch highlight drawn on GPU so it stays smooth even when the
    // cached canvas is not re-rendered.
    const auto pal = menu::CurrentPalette(g_settings);
    if (g_navAnimId >= 0 && g_navAnim < 1.f) {
        menu::Box navBox{};
        bool found = false;
        // local.rows are already menu-relative; adding layout.outer again
        // drew a stray highlight rectangle a few centimetres behind the menu.
        if (g_navAnimId >= 0 && g_navAnimId < static_cast<int>(menu::Tabs.size())) {
            navBox = local.rows[g_navAnimId];
            found = true;
        } else if ((g_navAnimId == 5 || g_navAnimId == 6) && local.visualsOpen) {
            navBox = local.visualRows[g_navAnimId - 5];
            found = true;
        } else if (g_navAnimId == 7) {
            navBox = local.extensionsRow;
            found = true;
        }
        if (found) {
            const float raw = std::clamp(g_navAnim, 0.f, 1.f);
            const float t = raw * raw * (3.f - 2.f * raw);
            const float a = .55f * (1.f - t);
            const menu::Box screenBox{navBox.x + layout.outer.x, navBox.y + layout.outer.y,
                                      navBox.w, navBox.h};
            dl->AddRectFilled({screenBox.x, screenBox.y},
                              {screenBox.x + screenBox.w, screenBox.y + screenBox.h},
                              imguiColor(Alpha(pal[33], a)), 8.f * g_settings.scale);
            dl->AddRectFilled({screenBox.x, screenBox.y},
                              {screenBox.x + 3.f * g_settings.scale, screenBox.y + screenBox.h},
                              imguiColor(Alpha(pal[23], .9f * (1.f - t))));
        }
        g_navAnim += dt / .28f;
        if (g_navAnim >= 1.f)
            g_navAnimId = -1;
    }

    // Hover overlay (not baked into cached canvas for FPS)
    for (std::size_t i = 0; i < frame.controls.size() && i < kAnimCount; ++i) {
        const float hover = g_controlHover[i];
        if (hover <= 0.01f) continue;
        const Control& c = frame.controls[i];
        if (c.kind == ControlKind::Info) continue;
        menu::Box r = c.box;
        r.x += layout.outer.x; r.y += layout.outer.y;
        float rr = 15.f * g_settings.scale / 1.6f;
        ImU32 col = imguiColor(Alpha(pal[33], .35f * hover));
        dl->AddRectFilled({r.x, r.y}, {r.x + r.w, r.y + r.h}, col, rr);
    }

    if (g_configDirty) {
        cfg.save();
        g_configDirty = false;
    }
}
