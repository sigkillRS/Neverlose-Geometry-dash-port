#include "config.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

namespace {

constexpr const char* SECTION = "Neverlose";

void configPath(char* out, size_t size) {
    char modulePath[MAX_PATH] = {0};
    if (!g_nlDllModule || !GetModuleFileNameA(g_nlDllModule, modulePath, MAX_PATH)) {
        GetModuleFileNameA(nullptr, modulePath, MAX_PATH);
    }

    char* slash = strrchr(modulePath, '\\');
    if (slash) {
        *(slash + 1) = '\0';
    } else {
        modulePath[0] = '\0';
    }

    _snprintf_s(out, size, _TRUNCATE, "%snl_standalone.ini", modulePath);
}

void slotPath(char* out, size_t size, int slot) {
    char modulePath[MAX_PATH] = {0};
    if (!g_nlDllModule || !GetModuleFileNameA(g_nlDllModule, modulePath, MAX_PATH)) {
        GetModuleFileNameA(nullptr, modulePath, MAX_PATH);
    }
    char* slash = strrchr(modulePath, '\\');
    if (slash) {
        *(slash + 1) = '\0';
    } else {
        modulePath[0] = '\0';
    }
    const int n = std::clamp(slot, 1, 5);
    _snprintf_s(out, size, _TRUNCATE, "%snl_standalone_cfg%d.ini", modulePath, n);
}

bool readBool(const char* path, const char* key, bool fallback) {
    char buf[16] = {0};
    GetPrivateProfileStringA(SECTION, key, fallback ? "1" : "0", buf, sizeof(buf), path);
    return buf[0] == '1' || _stricmp(buf, "true") == 0 || _stricmp(buf, "yes") == 0;
}

int readInt(const char* path, const char* key, int fallback) {
    return static_cast<int>(GetPrivateProfileIntA(SECTION, key, fallback, path));
}

float readFloat(const char* path, const char* key, float fallback) {
    char buf[32] = {0};
    _snprintf_s(buf, sizeof(buf), _TRUNCATE, "%.6f", fallback);
    GetPrivateProfileStringA(SECTION, key, buf, buf, sizeof(buf), path);
    return static_cast<float>(std::strtof(buf, nullptr));
}

float safeFloat(const char* path, const char* key, float fallback) {
    const float value = readFloat(path, key, fallback);
    return std::isfinite(value) ? value : fallback;
}

void writeBool(const char* path, const char* key, bool value) {
    WritePrivateProfileStringA(SECTION, key, value ? "1" : "0", path);
}

void writeInt(const char* path, const char* key, int value) {
    char buf[32];
    _snprintf_s(buf, sizeof(buf), _TRUNCATE, "%d", value);
    WritePrivateProfileStringA(SECTION, key, buf, path);
}

void writeFloat(const char* path, const char* key, float value) {
    char buf[32];
    _snprintf_s(buf, sizeof(buf), _TRUNCATE, "%.6f", value);
    WritePrivateProfileStringA(SECTION, key, buf, path);
}

} // namespace

Config& Config::get() {
    static Config instance;
    return instance;
}

void Config::load() {
    char path[MAX_PATH] = {0};
    configPath(path, sizeof(path));

    noclip = readBool(path, "noclip", false);
    godmode = readBool(path, "godmode", false);
    autoJump = readBool(path, "auto-jump", false);
    freezePlayer = readBool(path, "freeze-player", false);
    hidePlayer = readBool(path, "hide-player", false);
    hideHud = readBool(path, "hide-hud", false);
    hitboxes = readBool(path, "hitboxes", false);
    watermark = readBool(path, "watermark", true);
    fly = readBool(path, "fly", false);
    flySpeed = safeFloat(path, "fly-speed", 4.f);
    customTrail = readBool(path, "custom-trail", false);
    trailColor[0] = safeFloat(path, "trail-r", 0.545f);
    trailColor[1] = safeFloat(path, "trail-g", 0.502f);
    trailColor[2] = safeFloat(path, "trail-b", 0.976f);
    trailColor[3] = safeFloat(path, "trail-a", 1.f);
    showPercentage = readBool(path, "show-percentage", false);
    showCoords = readBool(path, "show-coords", false);
    streamproof = readBool(path, "streamproof", false);
    showKeybinds = readBool(path, "show-keybinds", false);
    menuOpen = readBool(path, "menuOpen", false);
    for (int i = 0; i < KEYBIND_COUNT; ++i) {
        char key[32] = {0};
        _snprintf_s(key, sizeof(key), _TRUNCATE, "keybind-%d-enabled", i);
        keybindEnabled[i] = readBool(path, key, i == 0);
        _snprintf_s(key, sizeof(key), _TRUNCATE, "keybind-%d-key", i);
        keybindKey[i] = readInt(path, key, VK_F1 + i);
        if (keybindKey[i] < 1 || keybindKey[i] > 254)
            keybindKey[i] = VK_F1 + i;
    }
    menuKey = readInt(path, "menu-key", VK_INSERT);
    if (menuKey < 1 || menuKey > 254 || menuKey == 'X')
        menuKey = VK_INSERT;
    speed = safeFloat(path, "speed", 1.f);
    accentHue = safeFloat(path, "accent-hue", 0.623f);
    if (std::fabs(accentHue - 0.72f) < 0.001f || std::fabs(accentHue - 0.627f) < 0.001f)
        accentHue = 0.623f;
    menuScale = std::clamp(safeFloat(path, "menu-scale", 1.f), .9f, 1.25f);
    watermarkX = safeFloat(path, "watermark-x", -1.f);
    watermarkY = safeFloat(path, "watermark-y", -1.f);
    keybindX = safeFloat(path, "keybind-x", -1.f);
    keybindY = safeFloat(path, "keybind-y", -1.f);
    if (std::fabs(watermarkX) > 100000.f) watermarkX = -1.f;
    if (std::fabs(watermarkY) > 100000.f) watermarkY = -1.f;
    if (std::fabs(keybindX) > 100000.f) keybindX = -1.f;
    if (std::fabs(keybindY) > 100000.f) keybindY = -1.f;
    tab = readInt(path, "tab", 0);
    visualSub = std::clamp(readInt(path, "visual-sub", 0), 0, 1);

    // Migrate old saved tab indices to the current four-tab layout.
    if (readInt(path, "tab-layout", 1) < 2) {
        if (tab == 1)
            tab = 0;
        else if (tab >= 2)
            --tab;
    }
    tab = std::clamp(tab, 0, 3);
}

void Config::save() const {
    char path[MAX_PATH] = {0};
    configPath(path, sizeof(path));

    writeBool(path, "noclip", noclip);
    writeBool(path, "godmode", godmode);
    writeBool(path, "auto-jump", autoJump);
    writeBool(path, "freeze-player", freezePlayer);
    writeBool(path, "hide-player", hidePlayer);
    writeBool(path, "hide-hud", hideHud);
    writeBool(path, "hitboxes", hitboxes);
    writeBool(path, "watermark", watermark);
    writeBool(path, "fly", fly);
    writeFloat(path, "fly-speed", flySpeed);
    writeBool(path, "custom-trail", customTrail);
    writeFloat(path, "trail-r", trailColor[0]);
    writeFloat(path, "trail-g", trailColor[1]);
    writeFloat(path, "trail-b", trailColor[2]);
    writeFloat(path, "trail-a", trailColor[3]);
    writeBool(path, "show-percentage", showPercentage);
    writeBool(path, "show-coords", showCoords);
    writeBool(path, "streamproof", streamproof);
    writeBool(path, "show-keybinds", showKeybinds);
    for (int i = 0; i < KEYBIND_COUNT; ++i) {
        char key[32] = {0};
        _snprintf_s(key, sizeof(key), _TRUNCATE, "keybind-%d-enabled", i);
        writeBool(path, key, keybindEnabled[i]);
        _snprintf_s(key, sizeof(key), _TRUNCATE, "keybind-%d-key", i);
        writeInt(path, key, keybindKey[i]);
    }
    writeInt(path, "menu-key", menuKey);
    writeFloat(path, "speed", speed);
    writeFloat(path, "accent-hue", accentHue);
    writeFloat(path, "menu-scale", menuScale);
    writeFloat(path, "watermark-x", watermarkX);
    writeFloat(path, "watermark-y", watermarkY);
    writeFloat(path, "keybind-x", keybindX);
    writeFloat(path, "keybind-y", keybindY);
    writeInt(path, "tab", tab);
    writeInt(path, "visual-sub", visualSub);
    writeInt(path, "tab-layout", 2);
    writeBool(path, "menuOpen", menuOpen);
}

bool Config::saveToSlot(int slot) const {
    save();
    char src[MAX_PATH] = {0}, dst[MAX_PATH] = {0};
    configPath(src, sizeof(src));
    slotPath(dst, sizeof(dst), slot);
    return CopyFileA(src, dst, FALSE) != 0;
}

bool Config::loadFromSlot(int slot) {
    char src[MAX_PATH] = {0}, dst[MAX_PATH] = {0};
    slotPath(src, sizeof(src), slot);
    configPath(dst, sizeof(dst));
    if (!CopyFileA(src, dst, FALSE))
        return false;
    load();
    return true;
}
