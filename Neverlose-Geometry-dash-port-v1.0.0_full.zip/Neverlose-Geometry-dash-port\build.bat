@echo off
setlocal EnableDelayedExpansion
pushd "%~dp0"

set "VCVARS=C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"
if not exist "%VCVARS%" set "VCVARS=C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
if not exist "%VCVARS%" (
    echo Could not find vcvars64.bat.
    popd
    exit /b 1
)

call "%VCVARS%"
if errorlevel 1 (
    echo Failed to initialize the Visual Studio x64 environment.
    popd
    exit /b 1
)

if not exist build mkdir build
if not exist build\ft mkdir build\ft

set "IMGUI=vendor\imgui"
set "OM=vendor\OverlayMenu"
set "FT=%OM%\third_party\freetype"
set "FTCFG=%OM%\freetype_config"
set "FLAGS=/nologo /W3 /EHsc /O2 /MD /std:c++17 /utf-8 /DWIN32_LEAN_AND_MEAN /DNOMINMAX /D_CRT_SECURE_NO_WARNINGS /I"%IMGUI%" /I"%IMGUI%\backends" /I"src""
set "MENUINC=/I"%OM%\src\core" /I"%OM%\src\render" /I"%OM%\src\ui" /I"%OM%\src\platform" /I"%OM%\src\inventory" /I"%OM%\src\preview" /I"%FTCFG%" /I"%FT%\include""

echo [1/6] Compiling ImGui...
cl %FLAGS% /Fo"build\imgui.obj" /c "%IMGUI%\imgui.cpp"
if errorlevel 1 goto :fail
cl %FLAGS% /Fo"build\imgui_draw.obj" /c "%IMGUI%\imgui_draw.cpp"
if errorlevel 1 goto :fail
cl %FLAGS% /Fo"build\imgui_tables.obj" /c "%IMGUI%\imgui_tables.cpp"
if errorlevel 1 goto :fail
cl %FLAGS% /Fo"build\imgui_widgets.obj" /c "%IMGUI%\imgui_widgets.cpp"
if errorlevel 1 goto :fail
cl %FLAGS% /Fo"build\imgui_impl_win32.obj" /c "%IMGUI%\backends\imgui_impl_win32.cpp"
if errorlevel 1 goto :fail
cl %FLAGS% /Fo"build\imgui_impl_opengl3.obj" /c "%IMGUI%\backends\imgui_impl_opengl3.cpp"
if errorlevel 1 goto :fail

echo [2/6] Compiling bundled FreeType...
set "FTINC=/I"%FTCFG%" /I"%FT%\include""
for /d %%D in ("%FT%\src\*") do set "FTINC=!FTINC! /I"%%D""
set "FTFLAGS=/nologo /W0 /MD /D_CRT_SECURE_NO_WARNINGS /DFT2_BUILD_LIBRARY"
set "FTOBJS="
for %%F in ("%FT%\src\base\*.c") do (
    if /I not "%%~nxF"=="ftbase.c" (
        cl %FTFLAGS% %FTINC% /Fo"build\ft\%%~nF.obj" /c "%%F" >nul
        if errorlevel 1 goto :fail
        set "FTOBJS=!FTOBJS! build\ft\%%~nF.obj"
    )
)
for %%F in ("%FT%\src\autofit\autofit.c" "%FT%\src\cff\cff.c" "%FT%\src\gzip\ftgzip.c" "%FT%\src\psaux\psaux.c" "%FT%\src\pshinter\pshinter.c" "%FT%\src\psnames\psnames.c" "%FT%\src\raster\raster.c" "%FT%\src\sfnt\sfnt.c" "%FT%\src\smooth\smooth.c" "%FT%\src\truetype\truetype.c") do (
    cl %FTFLAGS% %FTINC% /Fo"build\ft\%%~nF.obj" /c "%%F" >nul
    if errorlevel 1 goto :fail
    set "FTOBJS=!FTOBJS! build\ft\%%~nF.obj"
)

echo [3/6] Compiling project sources...
cl %FLAGS% /Fo"build\config.obj" /c "src\config.cpp"
if errorlevel 1 goto :fail
cl %FLAGS% /Fo"build\features.obj" /c "src\features.cpp"
if errorlevel 1 goto :fail
cl %FLAGS% /Fo"build\runtime.obj" /c "src\runtime.cpp"
if errorlevel 1 goto :fail
cl %FLAGS% %MENUINC% /Fo"build\menu.obj" /c "src\menu.cpp"
if errorlevel 1 goto :fail
cl %FLAGS% /Fo"build\dllmain.obj" /c "src\dllmain.cpp"
if errorlevel 1 goto :fail

echo [4/6] Compiling embedded fonts...
rc /nologo /I"src" /fo"build\resources.res" "resources.rc"
if errorlevel 1 goto :fail

echo [5/6] Linking StandaloneCheat.dll...
cl /nologo /LD /Fe:"build\StandaloneCheat.dll" ^
    build\imgui.obj ^
    build\imgui_draw.obj ^
    build\imgui_tables.obj ^
    build\imgui_widgets.obj ^
    build\imgui_impl_win32.obj ^
    build\imgui_impl_opengl3.obj ^
    build\config.obj ^
    build\features.obj ^
    build\runtime.obj ^
    build\menu.obj ^
    build\dllmain.obj ^
    !FTOBJS! ^
    build\resources.res ^
    /link /MACHINE:X64 /SUBSYSTEM:WINDOWS opengl32.lib user32.lib gdi32.lib
if errorlevel 1 goto :fail

echo [6/6] Building Injector.exe...
cl %FLAGS% /Fo"build\injector.obj" /Fe:"build\Injector.exe" "src\injector.cpp" /link /MACHINE:X64 /SUBSYSTEM:CONSOLE user32.lib kernel32.lib
if errorlevel 1 goto :fail

echo.
echo Build complete:
echo   %~dp0build\StandaloneCheat.dll
echo   %~dp0build\Injector.exe
popd
exit /b 0

:fail
echo.
echo Build failed.
popd
exit /b 1
