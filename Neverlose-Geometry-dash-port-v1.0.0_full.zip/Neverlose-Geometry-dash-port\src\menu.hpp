#pragma once

void nlSetupMenu();
void nlDrawMenu();
void nlHandleKeybind(int vk);
bool nlConsumeBindInput(int vk);
bool nlIsInputBlocked();
