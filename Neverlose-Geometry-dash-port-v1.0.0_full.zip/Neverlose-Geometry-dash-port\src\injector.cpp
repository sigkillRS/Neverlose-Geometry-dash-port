#include <windows.h>
#include <tlhelp32.h>

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

namespace {

constexpr const wchar_t* kTargetExe = L"GeometryDash.exe";
constexpr const char* kTargetName = "GeometryDash.exe";
constexpr const char* kDllName = "StandaloneCheat.dll";

constexpr WORD C_DEFAULT = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE;
constexpr WORD C_DIM = 8;
constexpr WORD C_ACCENT = FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_BLUE;
constexpr WORD C_GOOD = FOREGROUND_INTENSITY | FOREGROUND_GREEN;
constexpr WORD C_WARN = FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN;
constexpr WORD C_BAD = FOREGROUND_INTENSITY | FOREGROUND_RED;
constexpr WORD C_WHITE = FOREGROUND_INTENSITY | FOREGROUND_RED |
                         FOREGROUND_GREEN | FOREGROUND_BLUE;

constexpr int kBoxInner = 54;

HANDLE consoleOut() {
    return GetStdHandle(STD_OUTPUT_HANDLE);
}

void setColor(WORD attribute) {
    SetConsoleTextAttribute(consoleOut(), attribute);
}

void resetColor() {
    setColor(C_DEFAULT);
}

int consoleWidth() {
    CONSOLE_SCREEN_BUFFER_INFO info{};
    if (GetConsoleScreenBufferInfo(consoleOut(), &info) && info.dwSize.X > 20) {
        return info.dwSize.X;
    }
    return 80;
}

void clearScreen() {
    HANDLE output = consoleOut();
    CONSOLE_SCREEN_BUFFER_INFO info{};
    if (!GetConsoleScreenBufferInfo(output, &info)) return;

    const DWORD cells = static_cast<DWORD>(info.dwSize.X) *
                        static_cast<DWORD>(info.dwSize.Y);
    DWORD written = 0;
    const COORD origin{0, 0};

    FillConsoleOutputCharacterA(output, ' ', cells, origin, &written);
    FillConsoleOutputAttribute(output, C_DEFAULT, cells, origin, &written);
    SetConsoleCursorPosition(output, origin);
}

void printCentered(const char* text, WORD attribute) {
    const int width = consoleWidth();
    const int length = static_cast<int>(std::strlen(text));
    const int pad = length < width ? (width - length) / 2 : 0;

    setColor(attribute);
    std::printf("%*s%s\n", pad, "", text);
    resetColor();
}

void printRule(char character, WORD attribute) {
    const int width = std::min(consoleWidth() - 1, 78);
    setColor(attribute);
    for (int i = 0; i < width; ++i) {
        std::putchar(character);
    }
    std::putchar('\n');
    resetColor();
}

std::string fit(const std::string& text, size_t maxLength = kBoxInner) {
    if (text.size() <= maxLength) return text;
    if (maxLength <= 3) return text.substr(0, maxLength);
    return text.substr(0, maxLength - 3) + "...";
}

void printBoxTop() {
    setColor(C_ACCENT);
    std::putchar('+');
    for (int i = 0; i < kBoxInner + 2; ++i) std::putchar('-');
    std::putchar('+');
    std::putchar('\n');
    resetColor();
}

void printBoxRow(const char* key, const std::string& value, WORD valueColor) {
    std::string text = fit(std::string(key) + "  " + value);
    setColor(valueColor);
    std::printf("| %-*s |\n", kBoxInner, text.c_str());
    resetColor();
}

void printBoxText(const char* text, WORD color) {
    std::string fitted = fit(text);
    setColor(color);
    std::printf("| %-*s |\n", kBoxInner, fitted.c_str());
    resetColor();
}

void printBanner() {
    clearScreen();

    static const char* const kBanner[] = {
        R"(   _  _  ___  _   _  _____  _____  ____  _____  ____   )",
        R"(  | \| ||_ _|| \ | || ____|| ____||  _ \| ____||  _ \  )",
        R"(  | .` | | | |  \| || _|   | _|   | |_) | _|   | |_) | )",
        R"(  |_|\_||___||_|\__||_____||_____||____/|_____||____/  )"
    };

    for (const char* line : kBanner) {
        printCentered(line, C_ACCENT);
    }
    printCentered("GD INTERNAL  |  STANDALONE EDITION", C_DIM);
    printRule('-', C_ACCENT);
}

void printMenuPanel() {
    printBoxTop();
    printBoxText("SELECT ACTION", C_ACCENT);
    printBoxText("", C_DEFAULT);
    printBoxText("[1] Auto - inject or launch + inject", C_WHITE);
    printBoxText("[2] Inject into running game", C_WHITE);
    printBoxText("[3] Launch game + inject", C_WHITE);
    printBoxText("[4] Target status", C_WHITE);
    printBoxText("[0] Exit", C_DIM);
    printBoxTop();
}

void printUsage() {
    setColor(C_WHITE);
    std::printf("  Usage:\n");
    std::printf("    Injector.exe                 Auto mode (recommended)\n");
    std::printf("    Injector.exe --menu          Interactive styled menu\n");
    std::printf("    Injector.exe --inject        Inject into running game only\n");
    std::printf("    Injector.exe --launch        Launch game, then inject\n");
    std::printf("    Injector.exe --launch PATH   Launch a specific GeometryDash.exe\n");
    std::printf("    Injector.exe --status        Show target state\n");
    std::printf("    Injector.exe --help          Show this help\n");
    resetColor();
}

void step(const char* text) {
    setColor(C_DIM);
    std::printf("  *  %s\n", text);
    resetColor();
}

void stepOk(const char* text) {
    setColor(C_GOOD);
    std::printf("  OK  %s\n", text);
    resetColor();
}

void stepFail(const char* text) {
    setColor(C_BAD);
    std::printf("  !!  %s\n", text);
    resetColor();
}

void stepFail(const std::string& text) {
    stepFail(text.c_str());
}

void spinStep(const char* label, int tick) {
    static const char kFrames[] = "|/-\\";
    setColor(C_ACCENT);
    std::printf("\r  [%c] %-48s", kFrames[tick & 3], label);
    std::fflush(stdout);
    resetColor();
}

void clearSpin() {
    std::printf("\r%*s\r", 58, "");
    std::fflush(stdout);
}

bool waitForHandle(HANDLE handle, DWORD timeoutMs, const char* label, bool& timedOut) {
    const DWORD start = GetTickCount();
    int tick = 0;
    timedOut = false;

    for (;;) {
        const DWORD result = WaitForSingleObject(handle, 90);
        if (result == WAIT_OBJECT_0) {
            clearSpin();
            return true;
        }
        if (result != WAIT_TIMEOUT) {
            clearSpin();
            return false;
        }

        spinStep(label, tick++);
        if (GetTickCount() - start >= timeoutMs) {
            timedOut = true;
            clearSpin();
            return false;
        }
    }
}

DWORD g_waitPid = 0;
HWND g_waitWindow = nullptr;

BOOL CALLBACK findWindowProc(HWND hwnd, LPARAM) {
    if (!IsWindowVisible(hwnd)) return TRUE;

    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid != g_waitPid) return TRUE;

    wchar_t title[256] = {0};
    if (GetWindowTextW(hwnd, title, 256) > 0) {
        g_waitWindow = hwnd;
        return FALSE;
    }
    return TRUE;
}

bool waitForGameWindow(DWORD pid, DWORD timeoutMs) {
    const DWORD start = GetTickCount();
    int tick = 0;
    g_waitPid = pid;

    for (;;) {
        g_waitWindow = nullptr;
        EnumWindows(findWindowProc, 0);
        if (g_waitWindow) {
            clearSpin();
            Sleep(600);
            return true;
        }

        spinStep("Waiting for game window", tick++);
        if (GetTickCount() - start >= timeoutMs) {
            clearSpin();
            return false;
        }
        Sleep(80);
    }
}

std::wstring modulePathW() {
    wchar_t buffer[MAX_PATH] = {0};
    const DWORD length = GetModuleFileNameW(nullptr, buffer, MAX_PATH);
    if (length == 0 || length >= MAX_PATH) return L"";
    return std::wstring(buffer, length);
}

std::wstring moduleDirW() {
    const std::wstring path = modulePathW();
    const size_t slash = path.find_last_of(L"\\/");
    return slash == std::wstring::npos ? L"" : path.substr(0, slash);
}

std::wstring joinW(const std::wstring& directory, const wchar_t* name) {
    if (directory.empty()) return name;
    return directory + L"\\" + name;
}

bool fileExistsW(const std::wstring& path) {
    const DWORD attributes = GetFileAttributesW(path.c_str());
    return attributes != INVALID_FILE_ATTRIBUTES &&
           (attributes & FILE_ATTRIBUTE_DIRECTORY) == 0;
}

std::string wideToAnsi(const std::wstring& text) {
    const int length = WideCharToMultiByte(
        CP_ACP, 0, text.c_str(), static_cast<int>(text.size()),
        nullptr, 0, nullptr, nullptr);
    if (length <= 0) return "";

    std::string result(static_cast<size_t>(length), '\0');
    WideCharToMultiByte(
        CP_ACP, 0, text.c_str(), static_cast<int>(text.size()),
        &result[0], length, nullptr, nullptr);
    return result;
}

std::wstring ansiToWide(const std::string& text) {
    const int length = MultiByteToWideChar(
        CP_ACP, 0, text.c_str(), static_cast<int>(text.size()),
        nullptr, 0);
    if (length <= 0) return L"";

    std::wstring result(static_cast<size_t>(length), L'\0');
    MultiByteToWideChar(
        CP_ACP, 0, text.c_str(), static_cast<int>(text.size()),
        &result[0], length);
    return result;
}

bool resolveDllPath(std::string& out) {
    const std::wstring dllPath = joinW(moduleDirW(), L"StandaloneCheat.dll");
    out = wideToAnsi(dllPath);
    return fileExistsW(dllPath);
}

std::wstring defaultGamePathW() {
    const std::wstring start = moduleDirW();
    std::wstring directory = start;

    for (int depth = 0; depth < 8 && !directory.empty(); ++depth) {
        const std::wstring candidate = joinW(directory, kTargetExe);
        if (fileExistsW(candidate)) return candidate;

        const size_t slash = directory.find_last_of(L"\\/");
        if (slash == std::wstring::npos) break;
        directory = directory.substr(0, slash);
    }

    return joinW(start, kTargetExe);
}

std::vector<DWORD> findTargetProcesses() {
    std::vector<DWORD> pids;

    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) return pids;

    PROCESSENTRY32W entry{};
    entry.dwSize = sizeof(entry);

    if (Process32FirstW(snapshot, &entry)) {
        do {
            if (_wcsicmp(entry.szExeFile, kTargetExe) == 0) {
                pids.push_back(entry.th32ProcessID);
            }
        } while (Process32NextW(snapshot, &entry));
    }

    CloseHandle(snapshot);
    return pids;
}

std::string formatPids(const std::vector<DWORD>& pids) {
    if (pids.empty()) return "none";

    char buffer[128] = {0};
    size_t offset = 0;
    const size_t shown = std::min<size_t>(pids.size(), 3);

    for (size_t i = 0; i < shown; ++i) {
        offset += static_cast<size_t>(std::snprintf(
            buffer + offset, sizeof(buffer) - offset,
            "%s%lu", i == 0 ? "" : ", ", pids[i]));
    }
    if (pids.size() > shown) {
        std::snprintf(buffer + offset, sizeof(buffer) - offset,
                      " (+%zu)", pids.size() - shown);
    }
    return buffer;
}

void printStatusPanel(const std::vector<DWORD>& pids,
                      const std::string& dllPath, const char* mode) {
    const std::string pidText = formatPids(pids);
    const bool dllReady = fileExistsW(ansiToWide(dllPath));

    const std::wstring gamePath = defaultGamePathW();
    const bool gameReady = fileExistsW(gamePath);
    const std::string gameText = gameReady
        ? wideToAnsi(gamePath)
        : std::string("MISSING: ") + kTargetName;

    printBoxTop();
    printBoxRow("TARGET", kTargetName, C_WHITE);
    printBoxRow("PROCESS", pidText,
                pids.empty() ? C_DIM : (pids.size() == 1 ? C_GOOD : C_WARN));
    printBoxRow("GAME", gameText, gameReady ? C_GOOD : C_BAD);
    printBoxRow("MODULE", dllReady ? dllPath : std::string("MISSING: ") + kDllName,
                dllReady ? C_GOOD : C_BAD);
    printBoxRow("MODE", mode, C_ACCENT);
    printBoxTop();
}

bool is64BitProcess(HANDLE process) {
    BOOL wow64 = FALSE;
    if (IsWow64Process(process, &wow64)) {
        return wow64 == FALSE;
    }
    return true;
}

bool launchGame(const std::wstring& executable, DWORD& pid) {
    STARTUPINFOW startup{};
    startup.cb = sizeof(startup);
    PROCESS_INFORMATION processInfo{};

    std::wstring commandLine = L"\"" + executable + L"\"";
    if (!CreateProcessW(
            executable.c_str(), &commandLine[0], nullptr, nullptr, FALSE,
            0, nullptr, nullptr, &startup, &processInfo)) {
        return false;
    }

    CloseHandle(processInfo.hThread);
    CloseHandle(processInfo.hProcess);
    pid = processInfo.dwProcessId;
    return true;
}

struct RemoteCleanup {
    HANDLE process = nullptr;
    HANDLE thread = nullptr;
    LPVOID remotePath = nullptr;

    ~RemoteCleanup() {
        if (thread) CloseHandle(thread);
        if (remotePath && process) VirtualFreeEx(process, remotePath, 0, MEM_RELEASE);
        if (process) CloseHandle(process);
    }
};

bool injectInto(DWORD pid, const std::string& dllPath) {
    RemoteCleanup cleanup;
    char message[160] = {0};

    step("Opening target process");
    cleanup.process = OpenProcess(
        PROCESS_QUERY_INFORMATION | PROCESS_QUERY_LIMITED_INFORMATION |
        PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_CREATE_THREAD,
        FALSE, pid);
    if (!cleanup.process) {
        std::snprintf(message, sizeof(message),
                      "OpenProcess failed (error %lu). Try running as administrator.",
                      GetLastError());
        stepFail(message);
        return false;
    }
    stepOk("Process opened");

    if (!is64BitProcess(cleanup.process)) {
        stepFail("Target is 32-bit, but the module is x64.");
        return false;
    }

    const DWORD pathLength = static_cast<DWORD>(dllPath.size()) + 1;
    cleanup.remotePath = VirtualAllocEx(
        cleanup.process, nullptr, pathLength,
        MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!cleanup.remotePath) {
        std::snprintf(message, sizeof(message),
                      "VirtualAllocEx failed (error %lu).", GetLastError());
        stepFail(message);
        return false;
    }

    if (!WriteProcessMemory(cleanup.process, cleanup.remotePath,
                            dllPath.c_str(), pathLength, nullptr)) {
        std::snprintf(message, sizeof(message),
                      "WriteProcessMemory failed (error %lu).", GetLastError());
        stepFail(message);
        return false;
    }
    stepOk("Module path written");

    HMODULE kernel32 = GetModuleHandleA("kernel32.dll");
    FARPROC loadLibrary = kernel32 ? GetProcAddress(kernel32, "LoadLibraryA") : nullptr;
    if (!loadLibrary) {
        stepFail("Could not resolve LoadLibraryA.");
        return false;
    }

    cleanup.thread = CreateRemoteThread(
        cleanup.process, nullptr, 0,
        reinterpret_cast<LPTHREAD_START_ROUTINE>(loadLibrary),
        cleanup.remotePath, 0, nullptr);
    if (!cleanup.thread) {
        std::snprintf(message, sizeof(message),
                      "CreateRemoteThread failed (error %lu).", GetLastError());
        stepFail(message);
        return false;
    }
    stepOk("Loader thread created");

    bool timedOut = false;
    step("Loading module into target");
    if (!waitForHandle(cleanup.thread, 15000, "Loading module", timedOut)) {
        // The remote thread may still be reading the path; leave it allocated.
        cleanup.remotePath = nullptr;
        stepFail(timedOut ? "Loader thread timed out." : "Loader thread failed.");
        return false;
    }

    DWORD exitCode = 0;
    if (!GetExitCodeThread(cleanup.thread, &exitCode) || exitCode == 0) {
        stepFail("LoadLibraryA returned 0 inside the target.");
        return false;
    }

    stepOk("Module loaded");
    return true;
}

bool launchAndInjectSteps(const std::string& dllPath,
                          const std::wstring& gamePathArgument) {
    char message[160] = {0};

    const std::wstring gamePath = gamePathArgument.empty()
        ? defaultGamePathW()
        : gamePathArgument;

    if (!fileExistsW(gamePath)) {
        stepFail("GeometryDash.exe not found next to the injector.");
        step("Use: Injector.exe --launch \"C:\\path\\to\\GeometryDash.exe\"");
        return false;
    }

    DWORD pid = 0;
    step("Starting Geometry Dash");
    if (!launchGame(gamePath, pid)) {
        std::snprintf(message, sizeof(message),
                      "CreateProcessW failed (error %lu).", GetLastError());
        stepFail(message);
        return false;
    }
    std::snprintf(message, sizeof(message), "Game started (PID %lu)", pid);
    stepOk(message);

    step("Waiting for game window");
    if (!waitForGameWindow(pid, 30000)) {
        stepFail("Timed out waiting for the game window.");
        return false;
    }
    stepOk("Game window ready");

    const std::vector<DWORD> pids = findTargetProcesses();
    if (pids.size() != 1 || pids[0] != pid) {
        stepFail("Unexpected target instance count after launch.");
        return false;
    }

    return injectInto(pid, dllPath);
}

int injectExistingFlow() {
    printBanner();

    std::string dllPath;
    const bool dllReady = resolveDllPath(dllPath);
    const std::vector<DWORD> pids = findTargetProcesses();
    printStatusPanel(pids, dllPath, "INJECT");

    if (!dllReady) {
        stepFail(std::string(kDllName) + " is missing next to the injector.");
        return 1;
    }
    if (pids.empty()) {
        stepFail("No running Geometry Dash instance found.");
        step("Use --launch or menu option 3 to start the game.");
        return 1;
    }
    if (pids.size() != 1) {
        char message[96] = {0};
        std::snprintf(message, sizeof(message),
                      "Expected one instance, found %zu.", pids.size());
        stepFail(message);
        return 1;
    }

    return injectInto(pids[0], dllPath) ? 0 : 1;
}

int launchFlow(const std::wstring& gamePathArgument) {
    printBanner();

    std::string dllPath;
    const bool dllReady = resolveDllPath(dllPath);
    const std::vector<DWORD> pids = findTargetProcesses();
    printStatusPanel(pids, dllPath, "LAUNCH");

    if (!dllReady) {
        stepFail(std::string(kDllName) + " is missing next to the injector.");
        return 1;
    }
    if (pids.size() > 1) {
        char message[96] = {0};
        std::snprintf(message, sizeof(message),
                      "Expected zero or one instance, found %zu.", pids.size());
        stepFail(message);
        return 1;
    }
    if (pids.size() == 1) {
        step("Game already running; injecting into it instead.");
        return injectInto(pids[0], dllPath) ? 0 : 1;
    }

    return launchAndInjectSteps(dllPath, gamePathArgument) ? 0 : 1;
}

int autoFlow() {
    printBanner();

    std::string dllPath;
    const bool dllReady = resolveDllPath(dllPath);
    const std::vector<DWORD> pids = findTargetProcesses();
    printStatusPanel(pids, dllPath, "AUTO");

    if (!dllReady) {
        stepFail(std::string(kDllName) + " is missing next to the injector.");
        return 1;
    }
    if (pids.size() > 1) {
        char message[96] = {0};
        std::snprintf(message, sizeof(message),
                      "Found %zu instances; expected one or none.", pids.size());
        stepFail(message);
        return 1;
    }
    if (pids.size() == 1) {
        step("Running instance found; injecting.");
        return injectInto(pids[0], dllPath) ? 0 : 1;
    }

    step("No running instance; launching the game.");
    return launchAndInjectSteps(dllPath, L"") ? 0 : 1;
}

int statusOnly() {
    printBanner();
    std::string dllPath;
    resolveDllPath(dllPath);
    printStatusPanel(findTargetProcesses(), dllPath, "STATUS");
    return 0;
}

std::string trim(const std::string& text) {
    size_t begin = 0;
    while (begin < text.size() &&
           std::isspace(static_cast<unsigned char>(text[begin]))) {
        ++begin;
    }
    size_t end = text.size();
    while (end > begin &&
           std::isspace(static_cast<unsigned char>(text[end - 1]))) {
        --end;
    }
    return text.substr(begin, end - begin);
}

bool readLine(char* buffer, size_t size) {
    if (!std::fgets(buffer, static_cast<int>(size), stdin)) return false;
    buffer[std::strcspn(buffer, "\r\n")] = '\0';
    return true;
}

void pressEnter() {
    setColor(C_DIM);
    std::printf("\n  Press ENTER to continue...");
    resetColor();
    char buffer[8] = {0};
    std::fgets(buffer, static_cast<int>(sizeof(buffer)), stdin);
}

int finish(int result) {
    if (result == 0) {
        setColor(C_GOOD);
        std::printf("\n  READY. Press INSERT in game to open the menu.\n");
    } else {
        setColor(C_BAD);
        std::printf("\n  FAILED. See the message above.\n");
    }
    resetColor();
    return result;
}

int showMenu() {
    char input[64] = {0};

    for (;;) {
        printBanner();

        std::string dllPath;
        resolveDllPath(dllPath);
        printStatusPanel(findTargetProcesses(), dllPath, "MENU");
        printMenuPanel();

        setColor(C_ACCENT);
        std::printf("\n  Selection > ");
        resetColor();
        if (!readLine(input, sizeof(input))) break;

        const std::string choice = trim(input);
        if (choice == "0") break;

        int result = 0;
        if (choice == "1") {
            result = finish(autoFlow());
            pressEnter();
        } else if (choice == "2") {
            result = finish(injectExistingFlow());
            pressEnter();
        } else if (choice == "3") {
            result = finish(launchFlow(L""));
            pressEnter();
        } else if (choice == "4") {
            pressEnter();
        } else {
            setColor(C_WARN);
            std::printf("  Unknown selection: %s\n", choice.c_str());
            resetColor();
            pressEnter();
        }
        (void)result;
    }

    printBanner();
    setColor(C_DIM);
    std::printf("  Injector closed.\n");
    resetColor();
    return 0;
}

} // namespace

int main(int argc, char** argv) {
    SetConsoleTitleA("NEVERLOSE | GD INJECTOR");

    std::string option = argc > 1 ? argv[1] : "";

    if (option == "--help" || option == "-h") {
        printBanner();
        printUsage();
        return 0;
    }
    if (option == "--menu") {
        return showMenu();
    }
    if (option == "--status") {
        return statusOnly();
    }
    if (option == "--inject") {
        return finish(injectExistingFlow());
    }
    if (option == "--launch") {
        const std::wstring gamePath = argc > 2 ? ansiToWide(argv[2]) : L"";
        return finish(launchFlow(gamePath));
    }
    if (option == "--auto") {
        return finish(autoFlow());
    }

    if (!option.empty()) {
        const bool looksLikeExe = option.size() >= 4 &&
            _stricmp(option.substr(option.size() - 4).c_str(), ".exe") == 0;
        if (looksLikeExe) {
            return finish(launchFlow(ansiToWide(option)));
        }

        printBanner();
        setColor(C_BAD);
        std::printf("  Unknown option: %s\n", option.c_str());
        resetColor();
        printUsage();
        return 1;
    }

    return finish(autoFlow());
}
