# Туториал: GitHub + релиз

Ниже — пошагово. Все команды выполняются в PowerShell из папки проекта:

```powershell
cd "D:\Geometry Dash\mods-src\StandaloneCheat"
```

## 0. Подготовка

На этой машине `git` и `gh` не найдены. Установи:

- Git: <https://git-scm.com/download/win> (при установке оставь «Git from the command line and also from 3rd-party software»)
- GitHub CLI: <https://cli.github.com/> (установка через `winget install --id GitHub.cli` тоже подойдёт)

Проверь:

```powershell
git --version
gh --version
```

## 1. Создай репозиторий на GitHub

1. Зайди на <https://github.com/new>.
2. **Repository name:** `Neverlose-Geometry-dash-port`
3. **Description** (можно скопировать):

   ```text
   Standalone Neverlose-style canvas overlay for Geometry Dash x64. DLL + injector.
   ```

4. Выбери Public или Private.
5. **НЕ** ставь галочки `Add a README`, `Add .gitignore`, `Choose a license` — они уже есть локально.
6. Нажми **Create repository**.

После создания скопируй URL вида:

```text
https://github.com/<ТВОЙ_LOGIN>/Neverlose-Geometry-dash-port.git
```

## 2. Первый коммит и загрузка

```powershell
git init -b main
git add .
git commit -m "Initial import: standalone Neverlose-style overlay"
git remote add origin https://github.com/<ТВОЙ_LOGIN>/Neverlose-Geometry-dash-port.git
git push -u origin main
```

Замени `<ТВОЙ_LOGIN>` на свой логин GitHub.

Если `git init -b main` не сработал (старая версия Git):

```powershell
git init
git checkout -b main
```

Что попадёт в репозиторий:

- исходники `src/`, `build.bat`, `resources.rc`
- `vendor/imgui/` и `vendor/OverlayMenu/` (включая скомпилированные шрифты)
- готовые `build/StandaloneCheat.dll` и `build/Injector.exe` (как ты попросил — «и туда, и туда»)
- `README.md`, `LICENSE`, `THIRD_PARTY_NOTICES.md`, `GITHUB_RELEASE.md`, `RELEASE_NOTES.md`, `.gitignore`

Что **не** попадёт (благодаря `.gitignore`): `.obj`, `.res`, `.log`, временный `nl_standalone.ini`, мусор дизассемблера.

Проверить перед коммитом можно так:

```powershell
git status
git status --ignored
```

## 3. Что где писать

| Место | Что писать |
| --- | --- |
| README.md | Описание, фичи, сборка, запуск, клавиши, дисклеймер |
| LICENSE | MIT, `Copyright (c) 2026 barby` |
| THIRD_PARTY_NOTICES.md | Лицензии ImGui / FreeType / OverlayMenu / шрифтов |
| RELEASE_NOTES.md | Что нового именно в этом релизе; шаблон уже создан |
| Commit message | Коротко: `Initial import...`, затем `Fix input blocking`, `Add config slots` |
| Release title | `v1.0.0` или `v1.0.0 — standalone overlay` |
| Release tag | `v1.0.0` (префикс `v` — общепринятый) |

## 4. Создать релиз через сайт

1. Открой репозиторий → вкладка **Releases** справа.
2. **Draft a new release**.
3. **Choose a tag:** впиши `v1.0.0` → **Create new tag on publish**.
4. **Target:** выбери `main`.
5. **Release title:** `v1.0.0`.
6. В поле описания вставь содержимое `RELEASE_NOTES.md`.
7. **Attach binaries** — перетащи:

   ```text
   build\StandaloneCheat.dll
   build\Injector.exe
   ```

   Дополнительно можно прикрепить ZIP со всей папкой `build` (без `.obj`/`.log`).
8. Нажми **Publish release**.

## 5. Создать релиз через GitHub CLI

Сначала авторизуйся один раз:

```powershell
gh auth login
```

Затем:

```powershell
gh release create v1.0.0 `
  build/StandaloneCheat.dll `
  build/Injector.exe `
  --title "v1.0.0" `
  --notes-file RELEASE_NOTES.md
```

Если хочешь черновик (не публиковать сразу), добавь `--draft`. Если это
 превью-версия — добавь `--prerelease`.

Посмотреть результат:

```powershell
gh release view v1.0.0
```

## 6. Обновление в будущем

```powershell
git add .
git commit -m "Короткое описание изменений"
git push
```

Новый релиз:

```powershell
gh release create v1.1.0 build/StandaloneCheat.dll build/Injector.exe --title "v1.1.0" --notes-file RELEASE_NOTES.md
```

Не забудь перед каждым релизом обновить `RELEASE_NOTES.md` и пересобрать DLL/EXE:

```powershell
build.bat
```

## Важно

- В исходниках намеренно нет строк сторонних загрузчиков и номеров чужих версий. Не добавляй их в код.
- В `README` явно указано, что это **Neverlose-style menu** и независимая реализация.
- Если GitHub ругается на размер файлов — это маловероятно (DLL ~3 МБ), но можно
  держать бинарники только в Release и убрать их из `git add`.
