﻿#include "runtime.hpp"
#include "config.hpp"
#include "features.hpp"
#include "menu.hpp"
#include "offsets.hpp"

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_opengl3.h"

// The Win32 backend intentionally does not declare this in its header.
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);

#include <cstring>
#include <tlhelp32.h>

namespace nl {

namespace {

using UpdateFn = void(__fastcall*)(void*, float);
using DestroyPlayerFn = void(__fastcall*)(void*, void*, void*);
using VoidFn = void(__fastcall*)(void*);
using SwapBuffersFn = BOOL(WINAPI*)(HDC);
using GetAsyncKeyStateFn = SHORT(WINAPI*)(int);
using GetKeyStateFn = SHORT(WINAPI*)(int);
using GetKeyboardStateFn = BOOL(WINAPI*)(PBYTE);
using GetCursorPosFn = BOOL(WINAPI*)(LPPOINT);

uintptr_t g_base = 0;
void* g_playLayer = nullptr;
void* g_vtable = nullptr;

UpdateFn g_originalUpdate = nullptr;
DestroyPlayerFn g_originalDestroyPlayer = nullptr;
VoidFn g_originalCheckForEnd = nullptr;
SwapBuffersFn g_originalSwapBuffers = nullptr;
GetAsyncKeyStateFn g_originalGetAsyncKeyState = nullptr;
GetKeyStateFn g_originalGetKeyState = nullptr;
GetKeyboardStateFn g_originalGetKeyboardState = nullptr;
GetCursorPosFn g_originalGetCursorPos = nullptr;

bool g_hooksInstalled = false;
bool g_swapPatched = false;
bool g_imguiReady = false;
bool g_imguiInitializing = false;
bool g_inFrame = false;

HWND g_hwnd = nullptr;
WNDPROC g_originalWndProc = nullptr;

struct WindowSearch {
    HWND exact = nullptr;
    HWND fallback = nullptr;
};

BOOL CALLBACK findWindowProc(HWND hwnd, LPARAM lparam) {
    auto* search = reinterpret_cast<WindowSearch*>(lparam);
    if (!IsWindowVisible(hwnd)) return TRUE;

    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid != GetCurrentProcessId()) return TRUE;

    char title[256] = {0};
    const int length = GetWindowTextA(hwnd, title, sizeof(title));
    if (length <= 0) return TRUE;

    if (std::strstr(title, "Geometry Dash") != nullptr) {
        search->exact = hwnd;
        return FALSE;
    }

    if (!search->fallback) {
        search->fallback = hwnd;
    }
    return TRUE;
}

bool findGameWindow() {
    WindowSearch search;
    EnumWindows(findWindowProc, reinterpret_cast<LPARAM>(&search));
    g_hwnd = search.exact ? search.exact : search.fallback;
    return g_hwnd != nullptr;
}

template <class T>
T readVtableSlot(int index) {
    return reinterpret_cast<T>(*reinterpret_cast<void**>(
        reinterpret_cast<char*>(g_vtable) + static_cast<size_t>(index) * sizeof(void*)));
}

template <class T>
void writeVtableSlot(int index, T value) {
    void** slot = reinterpret_cast<void**>(
        reinterpret_cast<char*>(g_vtable) + static_cast<size_t>(index) * sizeof(void*));
    DWORD oldProtect = 0;
    if (VirtualProtect(slot, sizeof(void*), PAGE_READWRITE, &oldProtect)) {
        *slot = reinterpret_cast<void*>(value);
        DWORD ignored = 0;
        VirtualProtect(slot, sizeof(void*), oldProtect, &ignored);
        FlushInstructionCache(GetCurrentProcess(), slot, sizeof(void*));
    }
}

void __fastcall hookedUpdate(void* self, float dt) {
    auto& cfg = Config::get();

    const void* vt = self ? *reinterpret_cast<const void**>(self) : nullptr;
    if (vt == g_vtable) {
        if (g_playLayer != self) {
            g_playLayer = self;
            nl::OnLevelInit(self);
        }
    }

    float speed = cfg.speed;
    if (speed < 0.05f) speed = 0.05f;
    if (speed > 5.0f) speed = 5.0f;

    if (g_originalUpdate) {
        g_originalUpdate(self, dt * speed);
    }

    if (vt == g_vtable) {
        nl::UpdateGameplay(self);
    }
}

void __fastcall hookedDestroyPlayer(void* self, void* player, void* object) {
    if (Config::get().noclip) {
        if (player) {
            *reinterpret_cast<unsigned char*>(
                static_cast<char*>(player) + FIELD_PLAYER_IS_DEAD) = 0;
        }
        return;
    }

    if (g_originalDestroyPlayer) {
        g_originalDestroyPlayer(self, player, object);
    }
}

SHORT WINAPI hookedGetAsyncKeyState(int vKey) {
    if (nlIsInputBlocked())
        return 0;
    return g_originalGetAsyncKeyState ? g_originalGetAsyncKeyState(vKey) : 0;
}

SHORT WINAPI hookedGetKeyState(int vKey) {
    if (nlIsInputBlocked())
        return 0;
    return g_originalGetKeyState ? g_originalGetKeyState(vKey) : 0;
}

BOOL WINAPI hookedGetKeyboardState(PBYTE keyState) {
    if (nlIsInputBlocked()) {
        if (keyState)
            std::memset(keyState, 0, 256);
        return TRUE;
    }
    return g_originalGetKeyboardState ? g_originalGetKeyboardState(keyState) : FALSE;
}

BOOL WINAPI hookedGetCursorPos(LPPOINT point) {
    if (nlIsInputBlocked()) {
        if (point) {
            point->x = 0;
            point->y = 0;
        }
        return TRUE;
    }
    return g_originalGetCursorPos ? g_originalGetCursorPos(point) : FALSE;
}

LRESULT CALLBACK hookedWndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    auto& cfg = Config::get();

    if (g_imguiReady) {
        ImGui_ImplWin32_WndProcHandler(hwnd, msg, wparam, lparam);
    }

    if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) {
        if (nlConsumeBindInput(static_cast<int>(wparam)))
            return 0;
    } else if (msg == WM_LBUTTONDOWN || msg == WM_RBUTTONDOWN || msg == WM_MBUTTONDOWN ||
               msg == WM_XBUTTONDOWN) {
        int vk = VK_LBUTTON;
        if (msg == WM_RBUTTONDOWN) vk = VK_RBUTTON;
        else if (msg == WM_MBUTTONDOWN) vk = VK_MBUTTON;
        else if (msg == WM_XBUTTONDOWN) vk = (HIWORD(wparam) == XBUTTON1) ? 5 : 6;
        if (nlConsumeBindInput(vk))
            return 0;
    }

    if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) {
        const bool repeat = (lparam & (1 << 30)) != 0;
        if (wparam == static_cast<WPARAM>(cfg.menuKey) && !repeat) {
            cfg.menuOpen = !cfg.menuOpen;
            cfg.save();
            return 0;
        }
        if (cfg.menuOpen && wparam == 'X') {
            cfg.menuOpen = false;
            cfg.save();
            return 0;
        }
        if (!cfg.menuOpen && !repeat) {
            nlHandleKeybind(static_cast<int>(wparam));
        }
    }

    if (nlIsInputBlocked()) {
        switch (msg) {
            case WM_LBUTTONDOWN:
            case WM_LBUTTONUP:
            case WM_LBUTTONDBLCLK:
            case WM_RBUTTONDOWN:
            case WM_RBUTTONUP:
            case WM_RBUTTONDBLCLK:
            case WM_MBUTTONDOWN:
            case WM_MBUTTONUP:
            case WM_MBUTTONDBLCLK:
            case WM_MOUSEMOVE:
            case WM_MOUSEWHEEL:
            case WM_MOUSEHWHEEL:
            case WM_NCMOUSEMOVE:
            case WM_NCLBUTTONDOWN:
            case WM_NCLBUTTONUP:
            case WM_NCRBUTTONDOWN:
            case WM_NCRBUTTONUP:
            case WM_KEYDOWN:
            case WM_KEYUP:
            case WM_SYSKEYDOWN:
            case WM_SYSKEYUP:
            case WM_CHAR:
            case WM_INPUT:
            case 0x0240: // WM_TOUCH
            // Pointer / touch messages used by newer cocos builds.
            case 0x0245: // WM_POINTERUPDATE
            case 0x0246: // WM_POINTERDOWN
            case 0x0247: // WM_POINTERUP
            case 0x024E: // WM_POINTERWHEEL
            case WM_SETCURSOR:
                if (msg == WM_SETCURSOR)
                    SetCursor(LoadCursor(nullptr, IDC_ARROW));
                return 0;
            default:
                break;
        }
    }

    if (g_originalWndProc) {
        return CallWindowProcA(g_originalWndProc, hwnd, msg, wparam, lparam);
    }
    return DefWindowProcA(hwnd, msg, wparam, lparam);
}

void initImGui() {
    if (g_imguiReady || g_imguiInitializing) return;
    g_imguiInitializing = true;

    if (!findGameWindow()) {
        g_imguiInitializing = false;
        return;
    }

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;

    nlSetupMenu();

    ImGui_ImplWin32_Init(g_hwnd);
    ImGui_ImplOpenGL3_Init("#version 120");

    g_originalWndProc = reinterpret_cast<WNDPROC>(
        SetWindowLongPtrA(g_hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(hookedWndProc)));

    g_imguiReady = true;
    g_imguiInitializing = false;
}

void patchInputHooksAllModules();

void drawFrame() {
    if (!g_imguiReady || g_inFrame) return;
    g_inFrame = true;

    // Modules can be loaded late (or have delay-loaded imports resolved after
    // startup), so re-patch every input IAT slot periodically.
    static ULONGLONG lastInputPatch = 0;
    const ULONGLONG now = GetTickCount64();
    if (now - lastInputPatch > 500) {
        lastInputPatch = now;
        patchInputHooksAllModules();
    }

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    nlDrawMenu();

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    g_inFrame = false;
}

BOOL WINAPI hookedSwapBuffers(HDC hdc) {
    if (!g_imguiReady) {
        initImGui();
    }
    if (g_imguiReady) {
        drawFrame();
    }
    return g_originalSwapBuffers ? g_originalSwapBuffers(hdc) : TRUE;
}

void** findImportSlot(HMODULE module, const char* dllName, const char* functionName) {
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(module);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return nullptr;

    auto* nt = reinterpret_cast<IMAGE_NT_HEADERS64*>(
        reinterpret_cast<char*>(module) + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return nullptr;

    const IMAGE_DATA_DIRECTORY& dir =
        nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (!dir.VirtualAddress || !dir.Size) return nullptr;

    auto* base = reinterpret_cast<char*>(module);
    auto* descriptor = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(base + dir.VirtualAddress);

    for (; descriptor->Name; ++descriptor) {
        const char* name = base + descriptor->Name;
        if (_stricmp(name, dllName) != 0) continue;

        const uintptr_t lookupRva = descriptor->OriginalFirstThunk
            ? descriptor->OriginalFirstThunk
            : descriptor->FirstThunk;
        auto* lookup = reinterpret_cast<uintptr_t*>(base + lookupRva);
        auto* addressTable = reinterpret_cast<uintptr_t*>(base + descriptor->FirstThunk);

        for (size_t i = 0; lookup[i] != 0; ++i) {
            if (lookup[i] & IMAGE_ORDINAL_FLAG64) continue;
            auto* byName = reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(base + lookup[i]);
            if (_stricmp(byName->Name, functionName) == 0) {
                return reinterpret_cast<void**>(&addressTable[i]);
            }
        }
    }
    return nullptr;
}

bool patchImport(HMODULE module, const char* dllName, const char* functionName,
                 void* hook, void** originalSlot);

bool patchSwapBuffers(HMODULE cocos) {
    if (patchImport(cocos, "GDI32.dll", "SwapBuffers",
                    reinterpret_cast<void*>(hookedSwapBuffers),
                    reinterpret_cast<void**>(&g_originalSwapBuffers)))
        return true;

    // Fallback for the stripped import table in libcocos2d.dll.
    void** slot = reinterpret_cast<void**>(reinterpret_cast<char*>(cocos) +
                                           IAT_LIBCOCOS_SWAPBUFFERS);
    if (!slot || !*slot || *slot == reinterpret_cast<void*>(hookedSwapBuffers))
        return false;
    DWORD oldProtect = 0;
    if (!VirtualProtect(slot, sizeof(void*), PAGE_READWRITE, &oldProtect))
        return false;
    g_originalSwapBuffers = reinterpret_cast<SwapBuffersFn>(*slot);
    *slot = reinterpret_cast<void*>(hookedSwapBuffers);
    DWORD ignored = 0;
    VirtualProtect(slot, sizeof(void*), oldProtect, &ignored);
    FlushInstructionCache(GetCurrentProcess(), slot, sizeof(void*));
    return true;
}

bool patchImport(HMODULE module, const char* dllName, const char* functionName,
                 void* hook, void** originalSlot) {
    void** slot = findImportSlot(module, dllName, functionName);
    if (!slot || !*slot || *slot == hook)
        return false;

    DWORD oldProtect = 0;
    if (!VirtualProtect(slot, sizeof(void*), PAGE_READWRITE, &oldProtect))
        return false;
    if (originalSlot)
        *originalSlot = *slot;
    *slot = hook;
    DWORD ignored = 0;
    VirtualProtect(slot, sizeof(void*), oldProtect, &ignored);
    FlushInstructionCache(GetCurrentProcess(), slot, sizeof(void*));
    return true;
}

bool patchInputHooks(HMODULE module) {
    bool patched = false;
    patched |= patchImport(module, "USER32.dll", "GetAsyncKeyState",
                           reinterpret_cast<void*>(hookedGetAsyncKeyState),
                           reinterpret_cast<void**>(&g_originalGetAsyncKeyState));
    patched |= patchImport(module, "USER32.dll", "GetKeyState",
                           reinterpret_cast<void*>(hookedGetKeyState),
                           reinterpret_cast<void**>(&g_originalGetKeyState));
    patched |= patchImport(module, "USER32.dll", "GetKeyboardState",
                           reinterpret_cast<void*>(hookedGetKeyboardState),
                           reinterpret_cast<void**>(&g_originalGetKeyboardState));
    patched |= patchImport(module, "USER32.dll", "GetCursorPos",
                           reinterpret_cast<void*>(hookedGetCursorPos),
                           reinterpret_cast<void**>(&g_originalGetCursorPos));
    return patched;
}

void patchInputHooksAllModules() {
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, 0);
    if (snapshot == INVALID_HANDLE_VALUE)
        return;

    MODULEENTRY32 entry{};
    entry.dwSize = sizeof(entry);
    if (Module32First(snapshot, &entry)) {
        do {
            if (entry.hModule != g_nlDllModule)
                patchInputHooks(entry.hModule);
        } while (Module32Next(snapshot, &entry));
    }
    CloseHandle(snapshot);
}

void installVtableHooks() {
    if (g_hooksInstalled || !g_base) return;

    g_vtable = reinterpret_cast<void*>(g_base + RVA_PLAYLAYER_VFTABLE);

    g_originalUpdate = readVtableSlot<UpdateFn>(VTABLE_PLAYLAYER_UPDATE);
    g_originalDestroyPlayer = readVtableSlot<DestroyPlayerFn>(VTABLE_PLAYLAYER_DESTROY_PLAYER);
    g_originalCheckForEnd = readVtableSlot<VoidFn>(VTABLE_PLAYLAYER_CHECK_FOR_END);

    if (!g_originalUpdate || !g_originalDestroyPlayer) return;

    writeVtableSlot(VTABLE_PLAYLAYER_UPDATE, hookedUpdate);
    writeVtableSlot(VTABLE_PLAYLAYER_DESTROY_PLAYER, hookedDestroyPlayer);

    g_hooksInstalled = true;
}

} // namespace

void* ActivePlayLayer() {
    return g_playLayer;
}

} // namespace nl

DWORD WINAPI nlStartupThread(LPVOID) {
    Config::get().load();

    for (int attempt = 0; attempt < 200; ++attempt) {
        nl::g_base = nl::Base();
        if (nl::g_base) {
            nl::installVtableHooks();
            nl::patchInputHooks(reinterpret_cast<HMODULE>(nl::g_base));
            nl::patchInputHooksAllModules();
            if (nl::g_hooksInstalled) break;
        }
        Sleep(25);
    }

    for (int attempt = 0; attempt < 200; ++attempt) {
        HMODULE cocos = GetModuleHandleA("libcocos2d.dll");
        if (cocos && nl::patchSwapBuffers(cocos)) {
            nl::g_swapPatched = true;
            break;
        }
        Sleep(25);
    }

    return 0;
}
