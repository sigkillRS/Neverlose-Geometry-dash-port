#include "features.hpp"
#include "config.hpp"
#include "offsets.hpp"

#include <algorithm>
#include <cstring>

namespace nl {
namespace {

using SharedStateFn   = void* (__fastcall*)();
using CountForTypeFn  = int (__fastcall*)(void*, int);
using KeyFn           = void (__fastcall*)(void*, void*, int, int);
using StringDtorFn    = void (__fastcall*)(void*);
using CreateStringFn  = void* (__fastcall*)(const char*, int);
using SetObjectFn     = void (__fastcall*)(void*, void*, void*);
using SaveFn          = bool (__fastcall*)(void*, bool);
using VoidFn          = void (__fastcall*)(void*);
using ButtonFn        = void (__fastcall*)(void*, int);
using SetPosFn        = void (__fastcall*)(void*, float, float);
using GetPosFn        = void (__fastcall*)(void*, float*, float*);
using FloatFn         = float (__fastcall*)(void*);
using SetFloatFn      = void (__fastcall*)(void*, float);
using SetVisibleFn    = void (__fastcall*)(void*, bool);

bool s_debugOn = false;
bool s_hidPlayer = false;
bool s_hidHud = false;
int s_jumpCooldown1 = 0;
int s_jumpCooldown2 = 0;

void* gameManager() {
    static SharedStateFn fn = RvaFn<SharedStateFn>(RVA_GM_SHARED_STATE);
    return fn ? fn() : nullptr;
}

void setNodeVisible(void* node, bool visible) {
    if (!node) return;
    static SetVisibleFn fn = IatFn<SetVisibleFn>(IAT_CCNODE_SET_VISIBLE);
    if (fn) fn(node, visible);
}

void getPosition(void* node, float& x, float& y) {
    x = 0.f;
    y = 0.f;
    if (!node) return;
    static GetPosFn fn = IatFn<GetPosFn>(IAT_CCNODE_GET_POSITION);
    if (fn) fn(node, &x, &y);
}

void setPosition(void* node, float x, float y) {
    if (!node) return;
    static SetPosFn fn = IatFn<SetPosFn>(IAT_CCNODE_SET_POSITION_XY);
    if (fn) fn(node, x, y);
}

float getRotation(void* node) {
    if (!node) return 0.f;
    static FloatFn fn = IatFn<FloatFn>(IAT_CCNODE_GET_ROTATION);
    return fn ? fn(node) : 0.f;
}

void setRotation(void* node, float rotation) {
    if (!node) return;
    static SetFloatFn fn = IatFn<SetFloatFn>(IAT_CCNODE_SET_ROTATION);
    if (fn) fn(node, rotation);
}

void quickSave() {
    void* gm = gameManager();
    if (!gm) return;

    *reinterpret_cast<unsigned char*>(static_cast<char*>(gm) + FIELD_GM_QUICK_SAVE) = 1;

    static SaveFn save = RvaFn<SaveFn>(RVA_GMANAGER_SAVE);
    if (save) {
        save(gm, true);
    }

    *reinterpret_cast<unsigned char*>(static_cast<char*>(gm) + FIELD_GM_QUICK_SAVE) = 0;
}

void setUnlock(void* gm, void* dict, KeyFn keyFn, int id, int type) {
    if (!gm || !dict || !keyFn) return;

    alignas(16) unsigned char key[32] = {0};
    keyFn(gm, key, id, type);

    static CreateStringFn createString = IatFn<CreateStringFn>(IAT_CCSTRING_CREATE_FORMAT);
    static SetObjectFn setObject = IatFn<SetObjectFn>(IAT_CCDICTIONARY_SET_OBJECT);
    static StringDtorFn stringDtor = RvaFn<StringDtorFn>(RVA_STRING_DTOR);

    void* value = createString ? createString("%i", 1) : nullptr;
    if (value && setObject) {
        setObject(dict, value, key);
    }
    if (stringDtor) {
        stringDtor(key);
    }
}

void unlockIconSet(void* gm, void* dict, int iconType) {
    static CountForTypeFn countForType = RvaFn<CountForTypeFn>(RVA_GM_COUNT_FOR_TYPE);
    static KeyFn iconKey = RvaFn<KeyFn>(RVA_GM_ICON_KEY);

    if (!gm || !countForType || !iconKey) return;
    const int count = countForType(gm, iconType);
    if (count <= 0) return;

    for (int i = 1; i <= count; i++) {
        setUnlock(gm, dict, iconKey, i, iconType);
    }
}

void restorePlayerVisibility(void* pl) {
    if (!s_hidPlayer || !pl) return;
    setNodeVisible(*reinterpret_cast<void**>(static_cast<char*>(pl) + FIELD_PLAYER1), true);
    setNodeVisible(*reinterpret_cast<void**>(static_cast<char*>(pl) + FIELD_PLAYER2), true);
    s_hidPlayer = false;
}

void restoreHudVisibility(void* pl) {
    if (!s_hidHud || !pl) return;
    auto* base = static_cast<char*>(pl);
    setNodeVisible(*reinterpret_cast<void**>(base + FIELD_PL_ATTEMPT_LABEL), true);
    setNodeVisible(*reinterpret_cast<void**>(base + FIELD_PL_PERCENT_LABEL), true);
    setNodeVisible(*reinterpret_cast<void**>(base + FIELD_PL_PROGRESS_BAR), true);
    setNodeVisible(*reinterpret_cast<void**>(base + FIELD_PL_PROGRESS_FILL), true);
    setNodeVisible(*reinterpret_cast<void**>(base + FIELD_PL_STATUS_LABEL), true);
    s_hidHud = false;
}

} // namespace

void UnlockIcons() {
    void* gm = gameManager();
    if (!gm) return;

    void* dict = *reinterpret_cast<void**>(static_cast<char*>(gm) + FIELD_GM_VALUE_KEEPER);
    if (!dict) return;

    // IconType values: cube, ship, ball, ufo, wave, robot, spider, swing,
    // jetpack, ship fire, death effect.
    static constexpr int iconTypes[] = {
        0, 1, 2, 3, 4, 5, 6, 7, 8, 101, 98
    };

    for (int type : iconTypes) {
        unlockIconSet(gm, dict, type);
    }

    quickSave();
}

void UnlockColors() {
    void* gm = gameManager();
    if (!gm) return;

    void* dict = *reinterpret_cast<void**>(static_cast<char*>(gm) + FIELD_GM_VALUE_KEEPER);
    if (!dict) return;

    static KeyFn colorKey = RvaFn<KeyFn>(RVA_GM_COLOR_KEY);
    if (!colorKey) return;

    // UnlockType: Col1 = 2, Col2 = 3, Streak = 10.
    for (int i = 1; i <= 100; i++) {
        setUnlock(gm, dict, colorKey, i, 2);
        setUnlock(gm, dict, colorKey, i, 3);
    }
    for (int i = 1; i <= 32; i++) {
        setUnlock(gm, dict, colorKey, i, 10);
    }

    quickSave();
}

void UnlockAll() {
    UnlockIcons();
    UnlockColors();
}

void UnlockShipsBalls() {
    void* gm = gameManager();
    if (!gm) return;
    void* dict = *reinterpret_cast<void**>(static_cast<char*>(gm) + FIELD_GM_VALUE_KEEPER);
    if (!dict) return;
    // IconType 1 = ship, 2 = ball.
    unlockIconSet(gm, dict, 1);
    unlockIconSet(gm, dict, 2);
    quickSave();
}

bool GetPlayerState(float& x, float& y, float& progress) {
    x = y = progress = 0.f;
    void* pl = ActivePlayLayer();
    if (!pl) return false;

    auto* base = static_cast<char*>(pl);
    void* p1 = *reinterpret_cast<void**>(base + FIELD_PLAYER1);
    if (!p1) return false;

    getPosition(p1, x, y);
    const float length = *reinterpret_cast<float*>(base + FIELD_PL_LEVEL_LENGTH);
    if (length > 1.f)
        progress = std::clamp(x / length * 100.f, 0.f, 100.f);
    return true;
}

void TeleportToEnd() {
    void* pl = ActivePlayLayer();
    if (!pl) return;

    auto* base = static_cast<char*>(pl);
    float targetX = *reinterpret_cast<float*>(base + FIELD_PL_END_X_POSITION);
    if (targetX <= 0.f) {
        targetX = *reinterpret_cast<float*>(base + FIELD_PL_LEVEL_LENGTH);
    }
    targetX -= 35.f;

    void* p1 = *reinterpret_cast<void**>(base + FIELD_PLAYER1);
    void* p2 = *reinterpret_cast<void**>(base + FIELD_PLAYER2);

    if (p1) {
        float x = 0.f, y = 0.f;
        getPosition(p1, x, y);
        setPosition(p1, targetX, y);
        *reinterpret_cast<double*>(static_cast<char*>(p1) + FIELD_PLAYER_Y_VELOCITY) = 0.0;
    }
    if (p2) {
        float x = 0.f, y = 0.f;
        getPosition(p2, x, y);
        setPosition(p2, targetX - 25.f, y);
        *reinterpret_cast<double*>(static_cast<char*>(p2) + FIELD_PLAYER_Y_VELOCITY) = 0.0;
    }

    static VoidFn checkForEnd = RvaFn<VoidFn>(RVA_CHECK_FOR_END);
    if (checkForEnd) {
        checkForEnd(pl);
    }
}

void InstantComplete() {
    void* pl = ActivePlayLayer();
    if (!pl) return;

    static VoidFn levelComplete = RvaFn<VoidFn>(RVA_LEVEL_COMPLETE);
    if (levelComplete) {
        levelComplete(pl);
    }
}

void SetCheckpoint() {
    auto& cfg = Config::get();
    void* pl = ActivePlayLayer();
    if (!pl) return;

    auto* base = static_cast<char*>(pl);
    void* p1 = *reinterpret_cast<void**>(base + FIELD_PLAYER1);
    if (!p1) return;

    float x = 0.f, y = 0.f;
    getPosition(p1, x, y);
    cfg.checkpointX1 = x;
    cfg.checkpointY1 = y;
    cfg.checkpointRot1 = getRotation(p1);
    cfg.checkpointDual = *reinterpret_cast<void**>(base + FIELD_PLAYER2) != nullptr;

    if (cfg.checkpointDual) {
        void* p2 = *reinterpret_cast<void**>(base + FIELD_PLAYER2);
        getPosition(p2, x, y);
        cfg.checkpointX2 = x;
        cfg.checkpointY2 = y;
        cfg.checkpointRot2 = getRotation(p2);
    }

    cfg.checkpointSet = true;
}

void LoadCheckpoint() {
    auto& cfg = Config::get();
    void* pl = ActivePlayLayer();
    if (!pl || !cfg.checkpointSet) return;

    auto* base = static_cast<char*>(pl);
    void* p1 = *reinterpret_cast<void**>(base + FIELD_PLAYER1);
    if (p1) {
        setPosition(p1, cfg.checkpointX1, cfg.checkpointY1);
        setRotation(p1, cfg.checkpointRot1);
        *reinterpret_cast<double*>(static_cast<char*>(p1) + FIELD_PLAYER_Y_VELOCITY) = 0.0;
        *reinterpret_cast<unsigned char*>(static_cast<char*>(p1) + FIELD_PLAYER_IS_DEAD) = 0;
    }

    if (cfg.checkpointDual) {
        void* p2 = *reinterpret_cast<void**>(base + FIELD_PLAYER2);
        if (p2) {
            setPosition(p2, cfg.checkpointX2, cfg.checkpointY2);
            setRotation(p2, cfg.checkpointRot2);
            *reinterpret_cast<double*>(static_cast<char*>(p2) + FIELD_PLAYER_Y_VELOCITY) = 0.0;
            *reinterpret_cast<unsigned char*>(static_cast<char*>(p2) + FIELD_PLAYER_IS_DEAD) = 0;
        }
    }
}

void CaptureFreeze(void* pl) {
    auto& cfg = Config::get();
    if (!pl) return;

    auto* base = static_cast<char*>(pl);
    void* p1 = *reinterpret_cast<void**>(base + FIELD_PLAYER1);
    if (!p1) return;

    float x = 0.f, y = 0.f;
    getPosition(p1, x, y);
    cfg.freezeX1 = x;
    cfg.freezeY1 = y;
    cfg.freezeRot1 = getRotation(p1);
    cfg.freezeDual = *reinterpret_cast<void**>(base + FIELD_PLAYER2) != nullptr;

    if (cfg.freezeDual) {
        void* p2 = *reinterpret_cast<void**>(base + FIELD_PLAYER2);
        getPosition(p2, x, y);
        cfg.freezeX2 = x;
        cfg.freezeY2 = y;
        cfg.freezeRot2 = getRotation(p2);
    }

    cfg.freezeCaptured = true;
}

void ToggleHitboxes() {
    auto& cfg = Config::get();
    void* pl = ActivePlayLayer();
    if (!pl || s_debugOn == cfg.hitboxes) return;

    static VoidFn toggleDebugDraw = RvaFn<VoidFn>(RVA_TOGGLE_DEBUG_DRAW);
    if (toggleDebugDraw) {
        toggleDebugDraw(pl);
    }
    s_debugOn = cfg.hitboxes;
}

void OnLevelInit(void* pl) {
    auto& cfg = Config::get();
    s_debugOn = false;
    s_jumpCooldown1 = 0;
    s_jumpCooldown2 = 0;

    if (!pl) return;

    if (cfg.hitboxes) {
        static VoidFn toggleDebugDraw = RvaFn<VoidFn>(RVA_TOGGLE_DEBUG_DRAW);
        if (toggleDebugDraw) {
            toggleDebugDraw(pl);
        }
        s_debugOn = true;
    }

    cfg.freezeCaptured = false;
}

void UpdateGameplay(void* pl) {
    auto& cfg = Config::get();

    if (!pl) {
        restorePlayerVisibility(nullptr);
        restoreHudVisibility(nullptr);
        return;
    }

    auto* base = static_cast<char*>(pl);
    void* p1 = *reinterpret_cast<void**>(base + FIELD_PLAYER1);
    void* p2 = *reinterpret_cast<void**>(base + FIELD_PLAYER2);

    if (cfg.freezePlayer && !cfg.freezeCaptured) {
        CaptureFreeze(pl);
    }
    if (!cfg.freezePlayer && cfg.freezeCaptured) {
        cfg.freezeCaptured = false;
    }

    if (cfg.freezePlayer && cfg.freezeCaptured) {
        if (p1) {
            setPosition(p1, cfg.freezeX1, cfg.freezeY1);
            setRotation(p1, cfg.freezeRot1);
            *reinterpret_cast<double*>(static_cast<char*>(p1) + FIELD_PLAYER_Y_VELOCITY) = 0.0;
            *reinterpret_cast<unsigned char*>(static_cast<char*>(p1) + FIELD_PLAYER_IS_DEAD) = 0;
        }
        if (cfg.freezeDual && p2) {
            setPosition(p2, cfg.freezeX2, cfg.freezeY2);
            setRotation(p2, cfg.freezeRot2);
            *reinterpret_cast<double*>(static_cast<char*>(p2) + FIELD_PLAYER_Y_VELOCITY) = 0.0;
            *reinterpret_cast<unsigned char*>(static_cast<char*>(p2) + FIELD_PLAYER_IS_DEAD) = 0;
        }
    }

    if (cfg.godmode) {
        if (p1)
            *reinterpret_cast<unsigned char*>(static_cast<char*>(p1) + FIELD_PLAYER_IS_DEAD) = 0;
        if (p2)
            *reinterpret_cast<unsigned char*>(static_cast<char*>(p2) + FIELD_PLAYER_IS_DEAD) = 0;
    }

    if (cfg.fly && !cfg.freezePlayer) {
        const float lift = std::clamp(cfg.flySpeed, 0.5f, 30.f);
        if (p1) {
            float x = 0.f, y = 0.f;
            getPosition(p1, x, y);
            setPosition(p1, x, y - lift);
            *reinterpret_cast<double*>(static_cast<char*>(p1) + FIELD_PLAYER_Y_VELOCITY) = 0.0;
        }
        if (p2) {
            float x = 0.f, y = 0.f;
            getPosition(p2, x, y);
            setPosition(p2, x, y - lift);
            *reinterpret_cast<double*>(static_cast<char*>(p2) + FIELD_PLAYER_Y_VELOCITY) = 0.0;
        }
    }

    static ButtonFn pushButton = RvaFn<ButtonFn>(RVA_PLAYER_PUSH_BUTTON);
    static ButtonFn releaseButton = RvaFn<ButtonFn>(RVA_PLAYER_RELEASE_BUTTON);

    if (cfg.autoJump) {
        if (s_jumpCooldown1 > 0) {
            if (p1 && releaseButton) releaseButton(p1, 1);
            s_jumpCooldown1--;
        } else if (p1 && releaseButton && pushButton &&
                   *reinterpret_cast<unsigned char*>(static_cast<char*>(p1) + FIELD_PLAYER_IS_ON_GROUND)) {
            pushButton(p1, 1);
            s_jumpCooldown1 = 2;
        }

        if (s_jumpCooldown2 > 0) {
            if (p2 && releaseButton) releaseButton(p2, 1);
            s_jumpCooldown2--;
        } else if (p2 && releaseButton && pushButton &&
                   *reinterpret_cast<unsigned char*>(static_cast<char*>(p2) + FIELD_PLAYER_IS_ON_GROUND)) {
            pushButton(p2, 1);
            s_jumpCooldown2 = 2;
        }
    } else {
        if (s_jumpCooldown1 > 0 && p1 && releaseButton) releaseButton(p1, 1);
        if (s_jumpCooldown2 > 0 && p2 && releaseButton) releaseButton(p2, 1);
        s_jumpCooldown1 = 0;
        s_jumpCooldown2 = 0;
    }

    if (cfg.hidePlayer) {
        setNodeVisible(p1, false);
        setNodeVisible(p2, false);
        s_hidPlayer = true;
    } else {
        restorePlayerVisibility(pl);
    }

    if (cfg.hideHud) {
        setNodeVisible(*reinterpret_cast<void**>(base + FIELD_PL_ATTEMPT_LABEL), false);
        setNodeVisible(*reinterpret_cast<void**>(base + FIELD_PL_PERCENT_LABEL), false);
        setNodeVisible(*reinterpret_cast<void**>(base + FIELD_PL_PROGRESS_BAR), false);
        setNodeVisible(*reinterpret_cast<void**>(base + FIELD_PL_PROGRESS_FILL), false);
        setNodeVisible(*reinterpret_cast<void**>(base + FIELD_PL_STATUS_LABEL), false);
        s_hidHud = true;
    } else {
        restoreHudVisibility(pl);
    }
}

} // namespace nl
