#pragma once

namespace nl {

// Active PlayLayer tracked by the update hook.
void* ActivePlayLayer();

void UnlockIcons();
void UnlockColors();
void UnlockAll();
void UnlockShipsBalls();

// Returns player coordinates and level progress (0..100).
bool GetPlayerState(float& x, float& y, float& progress);

void TeleportToEnd();
void InstantComplete();
void SetCheckpoint();
void LoadCheckpoint();
void ToggleHitboxes();

void CaptureFreeze(void* playLayer);
void OnLevelInit(void* playLayer);
void UpdateGameplay(void* playLayer);

} // namespace nl
