#pragma once

#include <cstdint>
#include <windows.h>

namespace nl {

// Geometry Dash 2.2091 (x64) RVAs from the module image base.
inline constexpr uintptr_t RVA_GM_SHARED_STATE   = 0x2762c0;
inline constexpr uintptr_t RVA_GM_COUNT_FOR_TYPE = 0x27d010;
inline constexpr uintptr_t RVA_GM_ICON_KEY       = 0x2771b0;
inline constexpr uintptr_t RVA_GM_COLOR_KEY      = 0x277680;
inline constexpr uintptr_t RVA_GMANAGER_SAVE     = 0x77530;
inline constexpr uintptr_t RVA_STRING_DTOR       = 0x3d310;

inline constexpr uintptr_t RVA_PLAYER_PUSH_BUTTON   = 0x4f6200;
inline constexpr uintptr_t RVA_PLAYER_RELEASE_BUTTON = 0x4f64c0;
inline constexpr uintptr_t RVA_LEVEL_COMPLETE       = 0x5061b0;
inline constexpr uintptr_t RVA_TOGGLE_DEBUG_DRAW    = 0x505e40;
inline constexpr uintptr_t RVA_CHECK_FOR_END        = 0x513e60;

// Imported cocos2d functions in GeometryDash.exe (IAT RVAs).
inline constexpr uintptr_t IAT_CCSTRING_CREATE_FORMAT = 0x6d0088;
inline constexpr uintptr_t IAT_CCDICTIONARY_SET_OBJECT = 0x6d00a8;
inline constexpr uintptr_t IAT_CCNODE_SET_POSITION_XY  = 0x6d01b0;
inline constexpr uintptr_t IAT_CCNODE_GET_POSITION     = 0x6d01c0;
inline constexpr uintptr_t IAT_CCNODE_SET_ROTATION     = 0x6d0260;
inline constexpr uintptr_t IAT_CCNODE_GET_ROTATION     = 0x6d0268;
inline constexpr uintptr_t IAT_CCNODE_SET_VISIBLE      = 0x6d0250;

// libcocos2d.dll import slot fallback (GDI32!SwapBuffers).
inline constexpr uintptr_t IAT_LIBCOCOS_SWAPBUFFERS = 0xea038;

// Shared PlayLayer vftable. The RTTI pointer lives at RVA - 8.
inline constexpr uintptr_t RVA_PLAYLAYER_VFTABLE = 0x7d59b8;
inline constexpr int VTABLE_PLAYLAYER_UPDATE        = 4;
inline constexpr int VTABLE_PLAYLAYER_CHECK_FOR_END = 130;
inline constexpr int VTABLE_PLAYLAYER_DESTROY_PLAYER = 143;

// Field offsets.
inline constexpr uintptr_t FIELD_PLAYER1 = 0xdb8;
inline constexpr uintptr_t FIELD_PLAYER2 = 0xdc0;

inline constexpr uintptr_t FIELD_GM_VALUE_KEEPER = 0x1b0;
inline constexpr uintptr_t FIELD_GM_IS_SAVING    = 0x161;
inline constexpr uintptr_t FIELD_GM_QUICK_SAVE   = 0x162;

inline constexpr uintptr_t FIELD_PLAYER_Y_VELOCITY    = 0x9a8;
inline constexpr uintptr_t FIELD_PLAYER_IS_DEAD       = 0x9c8;
inline constexpr uintptr_t FIELD_PLAYER_IS_ON_GROUND  = 0x9c9;

inline constexpr uintptr_t FIELD_PL_STATUS_LABEL      = 0x3a08;
inline constexpr uintptr_t FIELD_PL_END_CHECKED       = 0x3a28;
inline constexpr uintptr_t FIELD_PL_END_X_POSITION    = 0x3a2c;
inline constexpr uintptr_t FIELD_PL_LEVEL_LENGTH      = 0x37a4;
inline constexpr uintptr_t FIELD_PL_ATTEMPT_LABEL     = 0x3a88;
inline constexpr uintptr_t FIELD_PL_PERCENT_LABEL     = 0x3a90;
inline constexpr uintptr_t FIELD_PL_DECIMAL_PERCENT   = 0x3a98;
inline constexpr uintptr_t FIELD_PL_HINT_SHOWN        = 0x3a99;
inline constexpr uintptr_t FIELD_PL_PROGRESS_BAR      = 0x3aa0;
inline constexpr uintptr_t FIELD_PL_PROGRESS_FILL     = 0x3aa8;
inline constexpr uintptr_t FIELD_PL_PROGRESS_WIDTH    = 0x3ab0;
inline constexpr uintptr_t FIELD_PL_PROGRESS_HEIGHT   = 0x3ab4;

inline uintptr_t Base() {
    return reinterpret_cast<uintptr_t>(GetModuleHandleA("GeometryDash.exe"));
}

inline void* Rva(uintptr_t rva) {
    return reinterpret_cast<void*>(Base() + rva);
}

inline void* Iat(uintptr_t rva) {
    return *reinterpret_cast<void**>(Base() + rva);
}

template <class T>
inline T RvaFn(uintptr_t rva) {
    return reinterpret_cast<T>(Rva(rva));
}

template <class T>
inline T IatFn(uintptr_t rva) {
    return reinterpret_cast<T>(Iat(rva));
}

} // namespace nl
