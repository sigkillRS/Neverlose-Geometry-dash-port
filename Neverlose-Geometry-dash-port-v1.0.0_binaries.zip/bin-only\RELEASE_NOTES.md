# v1.0.0

First public build of the standalone Neverlose-style canvas overlay for
Geometry Dash 2.2091 (x64).

## What is included

- Standalone `StandaloneCheat.dll` + `Injector.exe`; no loader/SDK/mod manager required
- Animated original-style canvas menu: General, Visuals (Players / World), Unlocks, Misc
- NL blue accent, fixed logo, enlarged rows/switches/sliders
- Draggable watermark and keybind list; LMB drag, RMB binding
- Three config slots, persisted in `nl_standalone.ini` beside the DLL
- Input blocking while the menu/overlays are active

## Files in this release

- `StandaloneCheat.dll`
- `Injector.exe`

## Quick start

```bat
Injector.exe --launch
```

Then press **INSERT** in game to open the menu, **X** to close it.

## Requirements

- Windows x64
- Geometry Dash 2.2091 (x64)
- Microsoft Visual C++ Redistributable 2022 x64

## Notes

This is an independent, unofficial Neverlose-style implementation by **barby**.
It is not affiliated with or endorsed by Neverlose or the game developers.
Use only in private/offline play and respect the game's rules.

See `README.md` in the repository for full build/usage instructions and
`THIRD_PARTY_NOTICES.md` for bundled component licenses.
