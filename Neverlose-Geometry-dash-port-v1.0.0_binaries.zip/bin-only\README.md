# Neverlose Geometry Dash Port

Standalone Windows DLL + injector for Geometry Dash 2.2091 (x64). The menu is a
**Neverlose-style canvas overlay** built on the vendored OverlayMenu shell.
ImGui is used only as a texture-blit / input host — this is not an ImGui-native
redesign and does not require any loader, SDK, or mod manager.

> Independent, unofficial implementation by **barby**. The visual style is
> Neverlose-style; this project is not affiliated with or endorsed by Neverlose
> or the game developers. Use only in private/offline play and respect the
> game's rules.

## Features

- Original-style canvas menu with animated tabs: **General**, **Visuals**
  (Players / World), **Unlocks**, **Misc**
- NL blue accent (native OverlayMenu palette), fixed logo, larger rows/switches
- Draggable watermark and keybind list; LMB drag on empty menu area
- RMB on a row / badge to rebind; `PRESS A KEY / MOUSE BUTTON` overlay
- Config slots: Save/Load 1–3, persisted in `nl_standalone.ini`
- Input blocking while the menu or an overlay is active
- Cached per-page canvases with slide/fade tab transition

## Files

| File | Purpose |
| --- | --- |
| `build/StandaloneCheat.dll` | Overlay + feature DLL |
| `build/Injector.exe` | Launcher/injector |
| `build/nl_standalone.ini` | Runtime config (generated next to DLL) |
| `build.bat` | MSVC x64 build script |
| `src/` | Project sources |
| `vendor/imgui/` | Bundled Dear ImGui (MIT) |
| `vendor/OverlayMenu/` | Bundled canvas shell, FreeType, fonts |
| `resources.rc`, `src/resources.hpp` | Embedded font resources |

## Build

Requirements:

- Windows x64
- Visual Studio 2022/2026 with **Desktop development with C++**
- `cl.exe` / `rc.exe` available via `vcvars64.bat` (located automatically by
  `build.bat`)

From this folder:

```bat
build.bat
```

Output:

```text
build\StandaloneCheat.dll
build\Injector.exe
```

## Usage

```bat
Injector.exe                 Auto mode (recommended)
Injector.exe --menu          Interactive styled menu
Injector.exe --inject        Inject into an already running game
Injector.exe --launch        Start the game, then inject
Injector.exe --launch PATH   Start a specific GeometryDash.exe, then inject
Injector.exe --status        Show target state
Injector.exe --help          Show help
```

In game:

- **INSERT** (or the configured `Menu Key`) — open/close the menu
- **X** — close the menu
- **LMB** — toggle switches / drag sliders / drag empty menu area / drag overlays
- **RMB** — bind a keybinding row or badge

Keybinds: Noclip, Godmode, Jump Hack, Speedhack, Fly, Hide Player, Hitboxes,
Watermark. Active binds are shown in the draggable keybind panel.

## Configuration

`nl_standalone.ini` is created beside `StandaloneCheat.dll`. Delete it to reset
everything to defaults. Three manual save slots are available from the Misc tab.

## Publish / release

See [GITHUB_RELEASE.md](GITHUB_RELEASE.md) for the full GitHub upload and
release tutorial. Release notes template: [RELEASE_NOTES.md](RELEASE_NOTES.md).

## License

MIT for the project code — see [LICENSE](LICENSE). Bundled third-party code and
fonts keep their own licenses — see [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
