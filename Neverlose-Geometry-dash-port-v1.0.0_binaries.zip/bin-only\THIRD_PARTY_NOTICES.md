# Third-party notices

This project bundles third-party code and assets. Their licenses remain in force.

| Component | Path | License / note |
| --- | --- | --- |
| Dear ImGui | `vendor/imgui/` | MIT — see `vendor/imgui/LICENSE.txt` |
| FreeType | `vendor/OverlayMenu/third_party/freetype/` | FreeType License / GPLv2 — see `vendor/OverlayMenu/third_party/freetype/LICENSE` |
| OverlayMenu canvas shell | `vendor/OverlayMenu/src/`, `vendor/OverlayMenu/assets/` | Vendored original source; used under its original terms |
| Fonts (Noto Sans, SmallFonts, etc.) | `vendor/OverlayMenu/assets/fonts/` | Supplied by their respective projects (e.g. SIL OFL for Noto Sans) |

The overlay visual style is Neverlose-style by design. This is an independent,
unofficial implementation by barby and is not affiliated with or endorsed by
Neverlose or the game developers.
